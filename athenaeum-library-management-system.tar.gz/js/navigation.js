/**
 * Athenaeum Navigation & Topbar Controller
 * Sidebar collapse, mobile drawer, theme switcher, notifications, and profile menu
 */

document.addEventListener('DOMContentLoaded', () => {
  Navigation.init();
});

const Navigation = {
  init() {
    this.initTheme();
    this.initSidebar();
    this.initProfileMenu();
    this.initGlobalSearch();
    this.updateNotificationBadge();
    this.highlightActiveNav();
  },

  /**
   * Theme toggling & storage sync
   */
  initTheme() {
    const savedTheme = window.StorageManager.getTheme();
    document.documentElement.setAttribute('data-theme', savedTheme);

    const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
    themeToggleBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme') || 'light';
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        window.StorageManager.setTheme(next);
        if (window.lucide) window.lucide.createIcons();
      });
    });
  },

  /**
   * Sidebar expand/collapse & mobile drawer
   */
  initSidebar() {
    const collapseBtn = document.getElementById('sidebar-collapse-btn');
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const mobileOverlay = document.getElementById('mobile-overlay');

    if (collapseBtn) {
      collapseBtn.addEventListener('click', () => {
        document.body.classList.toggle('sidebar-collapsed');
      });
    }

    if (mobileMenuBtn) {
      mobileMenuBtn.addEventListener('click', () => {
        document.body.classList.toggle('sidebar-open');
      });
    }

    if (mobileOverlay) {
      mobileOverlay.addEventListener('click', () => {
        document.body.classList.remove('sidebar-open');
      });
    }
  },

  /**
   * Profile dropdown menu
   */
  initProfileMenu() {
    const trigger = document.getElementById('profile-menu-trigger');
    const menu = document.getElementById('profile-dropdown');
    const logoutBtn = document.getElementById('logout-btn');

    if (trigger && menu) {
      trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        menu.classList.toggle('active');
      });

      document.addEventListener('click', () => {
        menu.classList.remove('active');
      });
    }

    if (logoutBtn) {
      logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        window.Auth.logout();
      });
    }
  },

  /**
   * Global search input keyboard shortcut (Cmd+K / Ctrl+K)
   */
  initGlobalSearch() {
    const searchInput = document.getElementById('global-search-input');
    if (!searchInput) return;

    window.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchInput.focus();
      }
    });

    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const query = searchInput.value.trim();
        if (query) {
          window.location.href = `/books.html?search=${encodeURIComponent(query)}`;
        }
      }
    });
  },

  /**
   * Notifications badge count in header
   */
  updateNotificationBadge() {
    const badge = document.getElementById('notification-dot');
    if (!badge) return;

    const notifs = window.StorageManager.getNotifications();
    const unreadCount = notifs.filter(n => !n.read).length;

    if (unreadCount > 0) {
      badge.style.display = 'block';
    } else {
      badge.style.display = 'none';
    }
  },

  /**
   * Highlight current page item in sidebar
   */
  highlightActiveNav() {
    const path = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-item a');
    
    navLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href && (path.endsWith(href) || (href === '/dashboard.html' && (path === '/' || path === '/dashboard.html')))) {
        link.parentElement.classList.add('active');
      } else {
        link.parentElement.classList.remove('active');
      }
    });
  }
};

window.Navigation = Navigation;
