/**
 * Athenaeum Author Management Controller
 * Author profiles, bibliography mapping, and author CRUD
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('authors-page-container')) {
    AuthorsController.init();
  }
});

const AuthorsController = {
  editingId: null,

  init() {
    this.bindEvents();
    this.render();
  },

  bindEvents() {
    const searchInput = document.getElementById('author-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', window.Utils.debounce(() => this.render(), 250));
    }

    const openAddBtn = document.getElementById('open-add-author-btn');
    const modalCloseBtn = document.getElementById('author-modal-close');
    const modalCancelBtn = document.getElementById('author-modal-cancel');
    const form = document.getElementById('author-form');

    if (openAddBtn) {
      openAddBtn.addEventListener('click', () => this.openAddModal());
    }
    if (modalCloseBtn) {
      modalCloseBtn.addEventListener('click', () => this.closeModal());
    }
    if (modalCancelBtn) {
      modalCancelBtn.addEventListener('click', () => this.closeModal());
    }
    if (form) {
      form.addEventListener('submit', (e) => this.handleFormSubmit(e));
    }
  },

  render() {
    const gridContainer = document.getElementById('authors-grid');
    if (!gridContainer) return;

    let authors = window.StorageManager.getAuthors();
    const books = window.StorageManager.getBooks();
    const searchInput = document.getElementById('author-search-input');
    const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

    if (q) {
      authors = authors.filter(a => 
        a.name.toLowerCase().includes(q) || 
        (a.country && a.country.toLowerCase().includes(q)) ||
        (a.biography && a.biography.toLowerCase().includes(q))
      );
    }

    if (authors.length === 0) {
      gridContainer.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          </div>
          <h3 class="empty-title">No authors match your search</h3>
          <p class="empty-desc">Check the author spelling or add a new author entry.</p>
        </div>
      `;
      return;
    }

    gridContainer.innerHTML = authors.map(author => {
      // Find books written by this author in catalog
      const authorBooks = books.filter(b => 
        b.author === author.name || b.authorId === author.id
      );

      return `
        <div class="card" style="display: flex; flex-direction: column;">
          <div class="card-body" style="flex: 1;">
            <div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; margin-bottom: 0.75rem;">
              <div>
                <h3 style="font-size: 1.125rem; font-weight: 700; color: var(--text-main);">${window.Utils.escapeHTML(author.name)}</h3>
                <div style="font-size: 0.8125rem; color: var(--accent-500); font-weight: 600; margin-top: 0.125rem;">
                  ${window.Utils.escapeHTML(author.country || 'International')}
                </div>
              </div>
              <span class="badge badge-neutral tabular-nums font-mono">${window.Utils.escapeHTML(author.id)}</span>
            </div>

            <p style="font-size: 0.8125rem; color: var(--text-muted); line-height: 1.5; margin-bottom: 1.25rem;">
              ${window.Utils.escapeHTML(author.biography || 'Scholar and author.')}
            </p>

            <div style="margin-top: auto; padding-top: 0.75rem; border-top: 1px solid var(--border-subtle);">
              <div style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-subtle); margin-bottom: 0.5rem;">
                Cataloged Works (${authorBooks.length})
              </div>
              <ul style="font-size: 0.8125rem; color: var(--text-main); display: flex; flex-direction: column; gap: 0.25rem;">
                ${authorBooks.slice(0, 3).map(b => `
                  <li style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                    <a href="/book-details.html?id=${b.id}" style="color: var(--accent-600); text-decoration: underline;">
                      ${window.Utils.escapeHTML(b.title)}
                    </a>
                  </li>
                `).join('')}
                ${authorBooks.length === 0 ? '<li style="color: var(--text-subtle); font-style: italic;">No books cataloged yet</li>' : ''}
              </ul>
            </div>
          </div>

          <div class="card-footer">
            <span style="font-size: 0.75rem; color: var(--text-muted);" class="tabular-nums">
              ${authorBooks.length} titles in collection
            </span>
            <div class="table-actions">
              <button class="action-icon-btn" onclick="AuthorsController.openEditModal('${author.id}')" title="Edit Author">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
              <button class="action-icon-btn delete-btn" onclick="AuthorsController.confirmDelete('${author.id}')" title="Delete Author">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  openAddModal() {
    this.editingId = null;
    const modal = document.getElementById('author-modal');
    const title = document.getElementById('author-modal-title');
    const form = document.getElementById('author-form');

    if (modal && title && form) {
      title.textContent = 'Add Author Profile';
      form.reset();
      window.Validation.clearAllErrors(form);
      modal.classList.add('active');
    }
  },

  openEditModal(authorId) {
    this.editingId = authorId;
    const authors = window.StorageManager.getAuthors();
    const author = authors.find(a => a.id === authorId);
    if (!author) return;

    const modal = document.getElementById('author-modal');
    const title = document.getElementById('author-modal-title');
    const form = document.getElementById('author-form');

    if (modal && title && form) {
      title.textContent = `Edit Author: ${author.name}`;
      window.Validation.clearAllErrors(form);

      document.getElementById('author-form-name').value = author.name || '';
      document.getElementById('author-form-country').value = author.country || '';
      document.getElementById('author-form-bio').value = author.biography || '';
      modal.classList.add('active');
    }
  },

  closeModal() {
    const modal = document.getElementById('author-modal');
    if (modal) modal.classList.remove('active');
    this.editingId = null;
  },

  handleFormSubmit(e) {
    e.preventDefault();
    const nameInput = document.getElementById('author-form-name');
    const countryInput = document.getElementById('author-form-country');
    const bioInput = document.getElementById('author-form-bio');

    const name = nameInput.value.trim();
    if (!name) {
      window.Validation.setFieldError(nameInput, 'Author name is required');
      return;
    }

    const authors = window.StorageManager.getAuthors();

    if (this.editingId) {
      const idx = authors.findIndex(a => a.id === this.editingId);
      if (idx !== -1) {
        authors[idx] = {
          ...authors[idx],
          name: name,
          country: countryInput.value.trim() || 'International',
          biography: bioInput.value.trim()
        };
        window.StorageManager.saveAuthors(authors);
        window.Utils.showToast('Author profile updated', 'success');
      }
    } else {
      const newId = window.Utils.generateId('AUT', authors);
      authors.push({
        id: newId,
        name: name,
        country: countryInput.value.trim() || 'International',
        biography: bioInput.value.trim() || 'Scholarly author.',
        booksWritten: 0
      });
      window.StorageManager.saveAuthors(authors);
      window.Utils.showToast('Author added to directory', 'success');
    }

    this.closeModal();
    this.render();
  },

  confirmDelete(authorId) {
    const authors = window.StorageManager.getAuthors();
    const author = authors.find(a => a.id === authorId);
    if (!author) return;

    window.Utils.confirmDialog({
      title: 'Delete Author Profile',
      message: `Are you sure you want to remove author "${author.name}"? Cataloged books by this author will remain preserved.`,
      confirmText: 'Delete Author',
      isDestructive: true,
      onConfirm: () => {
        const remaining = authors.filter(a => a.id !== authorId);
        window.StorageManager.saveAuthors(remaining);
        window.Utils.showToast('Author profile removed', 'success');
        this.render();
      }
    });
  }
};

window.AuthorsController = AuthorsController;
