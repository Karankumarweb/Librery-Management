/**
 * Athenaeum Supplier Management Controller
 * Supplier directory, vendor contracts, and supplier CRUD
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('suppliers-page-container')) {
    SuppliersController.init();
  }
});

const SuppliersController = {
  editingId: null,

  init() {
    this.bindEvents();
    this.render();
  },

  bindEvents() {
    const searchInput = document.getElementById('supplier-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', window.Utils.debounce(() => this.render(), 250));
    }

    const openAddBtn = document.getElementById('open-add-supplier-btn');
    const modalClose = document.getElementById('supplier-modal-close');
    const modalCancel = document.getElementById('supplier-modal-cancel');
    const form = document.getElementById('supplier-form');

    if (openAddBtn) {
      openAddBtn.addEventListener('click', () => this.openAddModal());
    }
    if (modalClose) {
      modalClose.addEventListener('click', () => this.closeModal());
    }
    if (modalCancel) {
      modalCancel.addEventListener('click', () => this.closeModal());
    }
    if (form) {
      form.addEventListener('submit', (e) => this.handleFormSubmit(e));
    }
  },

  render() {
    const tableBody = document.getElementById('suppliers-table-body');
    if (!tableBody) return;

    let suppliers = window.StorageManager.getSuppliers();
    const searchInput = document.getElementById('supplier-search-input');
    const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

    if (q) {
      suppliers = suppliers.filter(s => 
        s.companyName.toLowerCase().includes(q) ||
        s.contactPerson.toLowerCase().includes(q) ||
        s.email.toLowerCase().includes(q) ||
        (s.suppliedCategories && s.suppliedCategories.toLowerCase().includes(q))
      );
    }

    if (suppliers.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="6" style="text-align: center; padding: 2.5rem; color: var(--text-muted);">
            No suppliers match your search.
          </td>
        </tr>
      `;
      return;
    }

    tableBody.innerHTML = suppliers.map(s => {
      return `
        <tr>
          <td class="font-mono tabular-nums" style="font-weight: 600;">${s.id}</td>
          <td>
            <div style="font-weight: 700; color: var(--text-main); font-size: 0.9375rem;">${window.Utils.escapeHTML(s.companyName)}</div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">${window.Utils.escapeHTML(s.address)}</div>
          </td>
          <td>
            <div style="font-weight: 500;">${window.Utils.escapeHTML(s.contactPerson)}</div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">${window.Utils.escapeHTML(s.email)} · ${window.Utils.escapeHTML(s.phone)}</div>
          </td>
          <td style="font-size: 0.8125rem; color: var(--text-main); max-width: 280px;">
            ${window.Utils.escapeHTML(s.suppliedCategories || 'General Catalog')}
          </td>
          <td class="tabular-nums" style="text-align: center;">
            <span class="badge badge-info">${s.activeContracts || 1} active</span>
          </td>
          <td class="text-right">
            <div class="table-actions">
              <button class="action-icon-btn" onclick="SuppliersController.openEditModal('${s.id}')" title="Edit Supplier">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
              <button class="action-icon-btn delete-btn" onclick="SuppliersController.confirmDelete('${s.id}')" title="Delete Supplier">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openAddModal() {
    this.editingId = null;
    const modal = document.getElementById('supplier-modal');
    const title = document.getElementById('supplier-modal-title');
    const form = document.getElementById('supplier-form');

    if (modal && title && form) {
      title.textContent = 'Add Book Supplier / Vendor';
      form.reset();
      window.Validation.clearAllErrors(form);
      modal.classList.add('active');
    }
  },

  openEditModal(supId) {
    this.editingId = supId;
    const suppliers = window.StorageManager.getSuppliers();
    const sup = suppliers.find(s => s.id === supId);
    if (!sup) return;

    const modal = document.getElementById('supplier-modal');
    const title = document.getElementById('supplier-modal-title');
    const form = document.getElementById('supplier-form');

    if (modal && title && form) {
      title.textContent = `Edit Supplier: ${sup.companyName}`;
      window.Validation.clearAllErrors(form);

      document.getElementById('sup-form-name').value = sup.companyName || '';
      document.getElementById('sup-form-contact').value = sup.contactPerson || '';
      document.getElementById('sup-form-email').value = sup.email || '';
      document.getElementById('sup-form-phone').value = sup.phone || '';
      document.getElementById('sup-form-address').value = sup.address || '';
      document.getElementById('sup-form-categories').value = sup.suppliedCategories || '';
      modal.classList.add('active');
    }
  },

  closeModal() {
    const modal = document.getElementById('supplier-modal');
    if (modal) modal.classList.remove('active');
    this.editingId = null;
  },

  handleFormSubmit(e) {
    e.preventDefault();
    const nameInput = document.getElementById('sup-form-name');
    const contactInput = document.getElementById('sup-form-contact');
    const emailInput = document.getElementById('sup-form-email');
    const phoneInput = document.getElementById('sup-form-phone');
    const addressInput = document.getElementById('sup-form-address');
    const catInput = document.getElementById('sup-form-categories');

    let isValid = true;
    if (!nameInput.value.trim()) {
      window.Validation.setFieldError(nameInput, 'Company name is required');
      isValid = false;
    }
    if (!emailInput.value.trim() || !window.Validation.isValidEmail(emailInput.value)) {
      window.Validation.setFieldError(emailInput, 'Valid email required');
      isValid = false;
    }

    if (!isValid) return;

    const suppliers = window.StorageManager.getSuppliers();

    if (this.editingId) {
      const idx = suppliers.findIndex(s => s.id === this.editingId);
      if (idx !== -1) {
        suppliers[idx] = {
          ...suppliers[idx],
          companyName: nameInput.value.trim(),
          contactPerson: contactInput.value.trim(),
          email: emailInput.value.trim(),
          phone: phoneInput.value.trim(),
          address: addressInput.value.trim(),
          suppliedCategories: catInput.value.trim()
        };
        window.StorageManager.saveSuppliers(suppliers);
        window.Utils.showToast('Supplier record updated', 'success');
      }
    } else {
      const newId = window.Utils.generateId('SUP', suppliers);
      suppliers.push({
        id: newId,
        companyName: nameInput.value.trim(),
        contactPerson: contactInput.value.trim(),
        email: emailInput.value.trim(),
        phone: phoneInput.value.trim(),
        address: addressInput.value.trim(),
        suppliedCategories: catInput.value.trim() || 'General Library Books',
        activeContracts: 1
      });
      window.StorageManager.saveSuppliers(suppliers);
      window.Utils.showToast('Supplier registered successfully', 'success');
    }

    this.closeModal();
    this.render();
  },

  confirmDelete(supId) {
    const suppliers = window.StorageManager.getSuppliers();
    const sup = suppliers.find(s => s.id === supId);
    if (!sup) return;

    window.Utils.confirmDialog({
      title: 'Delete Supplier',
      message: `Are you sure you want to remove supplier "${sup.companyName}"?`,
      confirmText: 'Delete Supplier',
      isDestructive: true,
      onConfirm: () => {
        const remaining = suppliers.filter(s => s.id !== supId);
        window.StorageManager.saveSuppliers(remaining);
        window.Utils.showToast('Supplier deleted', 'success');
        this.render();
      }
    });
  }
};

window.SuppliersController = SuppliersController;
