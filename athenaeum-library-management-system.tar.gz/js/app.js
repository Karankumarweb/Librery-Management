/**
 * Athenaeum Core Application Orchestrator
 * Shared initialization across all authenticated dashboard views
 */

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

const App = {
  init() {
    const publicPages = ['index.html', 'login.html', 'register.html', '404.html'];
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';

    // If on a private management page, enforce auth
    if (!publicPages.includes(currentPath) && currentPath !== '') {
      if (!window.Auth.requireAuth()) return;
    }

    this.renderHeaderUserInfo();
    this.initLucideIcons();
    this.initDemoResetButton();
  },

  renderHeaderUserInfo() {
    const user = window.Auth.getCurrentUser();
    if (!user) return;

    // Header elements
    const nameEl = document.querySelector('.profile-name-top');
    const avatarEl = document.querySelector('.profile-avatar-top');
    const roleEl = document.querySelector('.user-role-compact');
    const sideNameEl = document.querySelector('.user-name-compact');
    const sideAvatarEl = document.querySelector('.user-avatar-mini');

    if (nameEl) nameEl.textContent = user.name;
    if (avatarEl) avatarEl.src = user.avatar || '/assets/images/avatars/avatar-1.svg';
    if (roleEl) roleEl.textContent = user.role;
    if (sideNameEl) sideNameEl.textContent = user.name;
    if (sideAvatarEl) sideAvatarEl.src = user.avatar || '/assets/images/avatars/avatar-1.svg';

    // Role-based navigation adaptation
    if (user.role === 'Member') {
      const restrictedLinks = document.querySelectorAll('.admin-only');
      restrictedLinks.forEach(el => el.style.display = 'none');
    }
  },

  initLucideIcons() {
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
  },

  initDemoResetButton() {
    const resetBtn = document.getElementById('reset-demo-data-btn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        window.Utils.confirmDialog({
          title: 'Reset All Demo Data',
          message: 'This will restore all books, members, transactions, and settings to the original default seed data. All custom modifications will be reset.',
          confirmText: 'Reset Demo Data',
          isDestructive: true,
          onConfirm: () => {
            window.StorageManager.resetToDefaults();
            window.Utils.showToast('Demo data reset to factory defaults', 'success');
            setTimeout(() => window.location.reload(), 1000);
          }
        });
      });
    }
  }
};

window.App = App;
