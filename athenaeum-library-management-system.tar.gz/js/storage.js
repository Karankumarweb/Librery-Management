/**
 * Centralized Storage Manager & Comprehensive Demo Seed Data
 * Athenaeum Library Management System
 */

const STORAGE_KEYS = {
  BOOKS: 'lms_books_v1',
  AUTHORS: 'lms_authors_v1',
  CATEGORIES: 'lms_categories_v1',
  MEMBERS: 'lms_members_v1',
  SUPPLIERS: 'lms_suppliers_v1',
  LOANS: 'lms_loans_v1',
  RESERVATIONS: 'lms_reservations_v1',
  FINES: 'lms_fines_v1',
  NOTIFICATIONS: 'lms_notifications_v1',
  SETTINGS: 'lms_settings_v1',
  CURRENT_USER: 'lms_current_user_v1',
  THEME: 'lms_theme_v1',
  INITIALIZED: 'lms_initialized_v1'
};

const DEFAULT_SETTINGS = {
  libraryName: 'Athenaeum University Central Library',
  libraryEmail: 'circulation@athenaeum.edu',
  libraryPhone: '+1 (555) 349-8200',
  libraryAddress: '450 University Avenue, Cambridge, MA 02138',
  loanDurationDays: 14,
  maxBooksPerMember: 5,
  dailyFineRate: 0.50,
  currency: 'USD',
  allowSelfRegistration: true
};

const SEED_CATEGORIES = [
  { id: 'CAT-01', name: 'Computer Science', description: 'Algorithms, artificial intelligence, software engineering, systems', count: 5 },
  { id: 'CAT-02', name: 'Literature & Fiction', description: 'Classic and contemporary literary novels, anthologies, drama', count: 4 },
  { id: 'CAT-03', name: 'Physical Sciences', description: 'Theoretical physics, astronomy, chemistry, thermodynamics', count: 4 },
  { id: 'CAT-04', name: 'Economics & Finance', description: 'Macroeconomics, behavioral finance, international markets', count: 3 },
  { id: 'CAT-05', name: 'World History', description: 'Ancient civilizations, global conflicts, cultural historiography', count: 3 },
  { id: 'CAT-06', name: 'Medical Sciences', description: 'Human anatomy, pathology, biochemistry, clinical practice', count: 3 },
  { id: 'CAT-07', name: 'Philosophy & Ethics', description: 'Political theory, epistemology, logic, moral philosophy', count: 3 },
  { id: 'CAT-08', name: 'Law & Jurisprudence', description: 'Constitutional law, torts, international conventions, human rights', count: 3 },
  { id: 'CAT-09', name: 'Behavioral Sciences', description: 'Cognitive psychology, neuropsychology, organizational behavior', count: 4 }
];

const SEED_AUTHORS = [
  { id: 'AUT-01', name: 'Thomas H. Cormen', country: 'United States', biography: 'Professor Emeritus of Computer Science at Dartmouth College and co-author of Introduction to Algorithms.', booksWritten: 2 },
  { id: 'AUT-02', name: 'Jane Austen', country: 'United Kingdom', biography: 'English novelist known for her realism, biting social commentary, and mastery of free indirect discourse.', booksWritten: 3 },
  { id: 'AUT-03', name: 'Dr. Stephen Hawking', country: 'United Kingdom', biography: 'World-renowned theoretical physicist, cosmologist, and author of A Brief History of Time.', booksWritten: 2 },
  { id: 'AUT-04', name: 'N. Gregory Mankiw', country: 'United States', biography: 'Robert M. Beren Professor of Economics at Harvard University and former Chairman of the CEA.', booksWritten: 2 },
  { id: 'AUT-05', name: 'Yuval Noah Harari', country: 'Israel', biography: 'Historian, philosopher, and professor in the Department of History at the Hebrew University of Jerusalem.', booksWritten: 3 },
  { id: 'AUT-06', name: 'Gerard J. Tortora', country: 'United States', biography: 'Professor of Biology at Bergen Community College, specializing in anatomy and physiology.', booksWritten: 2 },
  { id: 'AUT-07', name: 'Ian Goodfellow', country: 'United States', biography: 'Computer scientist and pioneer in generative adversarial networks (GANs) and deep neural architectures.', booksWritten: 2 },
  { id: 'AUT-08', name: 'Plato', country: 'Ancient Greece', biography: 'Athenian philosopher during the Classical period in Ancient Greece, founder of the Academy.', booksWritten: 2 },
  { id: 'AUT-09', name: 'Erwin Chemerinsky', country: 'United States', biography: 'Dean of UC Berkeley School of Law and acclaimed constitutional law scholar.', booksWritten: 2 },
  { id: 'AUT-10', name: 'Daniel Kahneman', country: 'Israel', biography: 'Psychologist and Nobel Memorial Prize laureate in Economic Sciences for behavioral economics.', booksWritten: 2 }
];

const SEED_BOOKS = [
  {
    id: 'BK-1001',
    isbn: '978-0262046305',
    title: 'Introduction to Algorithms, 4th Edition',
    author: 'Thomas H. Cormen',
    authorId: 'AUT-01',
    category: 'Computer Science',
    categoryId: 'CAT-01',
    publisher: 'MIT Press',
    publicationYear: 2022,
    language: 'English',
    shelfNumber: 'A-12-04',
    totalCopies: 8,
    availableCopies: 6,
    price: 94.50,
    coverImage: '/assets/images/book-covers/cover-1.svg',
    description: 'A comprehensive textbook covering the modern study of computer algorithms with depth and rigor.'
  },
  {
    id: 'BK-1002',
    isbn: '978-0141439518',
    title: 'Pride and Prejudice',
    author: 'Jane Austen',
    authorId: 'AUT-02',
    category: 'Literature & Fiction',
    categoryId: 'CAT-02',
    publisher: 'Penguin Classics',
    publicationYear: 2003,
    language: 'English',
    shelfNumber: 'L-04-18',
    totalCopies: 6,
    availableCopies: 4,
    price: 14.99,
    coverImage: '/assets/images/book-covers/cover-2.svg',
    description: 'The romantic clash between the opinionated Elizabeth Bennet and her proud beau, Mr. Darcy.'
  },
  {
    id: 'BK-1003',
    isbn: '978-0553380163',
    title: 'A Brief History of Time',
    author: 'Dr. Stephen Hawking',
    authorId: 'AUT-03',
    category: 'Physical Sciences',
    categoryId: 'CAT-03',
    publisher: 'Bantam Books',
    publicationYear: 1998,
    language: 'English',
    shelfNumber: 'P-08-02',
    totalCopies: 5,
    availableCopies: 2,
    price: 22.00,
    coverImage: '/assets/images/book-covers/cover-3.svg',
    description: 'Explores profound questions regarding the creation of the cosmos, black holes, and the nature of time.'
  },
  {
    id: 'BK-1004',
    isbn: '978-1305580862',
    title: 'Principles of Macroeconomics',
    author: 'N. Gregory Mankiw',
    authorId: 'AUT-04',
    category: 'Economics & Finance',
    categoryId: 'CAT-04',
    publisher: 'Cengage Learning',
    publicationYear: 2020,
    language: 'English',
    shelfNumber: 'E-03-11',
    totalCopies: 7,
    availableCopies: 5,
    price: 185.00,
    coverImage: '/assets/images/book-covers/cover-4.svg',
    description: 'A thorough introduction emphasizing market dynamics, fiscal policy, inflation, and monetary theory.'
  },
  {
    id: 'BK-1005',
    isbn: '978-0062316097',
    title: 'Sapiens: A Brief History of Humankind',
    author: 'Yuval Noah Harari',
    authorId: 'AUT-05',
    category: 'World History',
    categoryId: 'CAT-05',
    publisher: 'Harper',
    publicationYear: 2015,
    language: 'English',
    shelfNumber: 'H-09-07',
    totalCopies: 9,
    availableCopies: 7,
    price: 24.99,
    coverImage: '/assets/images/book-covers/cover-5.svg',
    description: '100,000 years ago, at least six human species inhabited the earth. Today there is just one: us.'
  },
  {
    id: 'BK-1006',
    isbn: '978-1119704386',
    title: 'Principles of Anatomy and Physiology',
    author: 'Gerard J. Tortora',
    authorId: 'AUT-06',
    category: 'Medical Sciences',
    categoryId: 'CAT-06',
    publisher: 'Wiley',
    publicationYear: 2021,
    language: 'English',
    shelfNumber: 'M-05-15',
    totalCopies: 4,
    availableCopies: 1,
    price: 198.50,
    coverImage: '/assets/images/book-covers/cover-6.svg',
    description: 'Setting the standard for two-semester anatomy and physiology courses with rigorous histology coverage.'
  },
  {
    id: 'BK-1007',
    isbn: '978-0262035613',
    title: 'Deep Learning',
    author: 'Ian Goodfellow',
    authorId: 'AUT-07',
    category: 'Artificial Intelligence',
    categoryId: 'CAT-01',
    publisher: 'MIT Press',
    publicationYear: 2016,
    language: 'English',
    shelfNumber: 'A-14-01',
    totalCopies: 6,
    availableCopies: 0,
    price: 88.00,
    coverImage: '/assets/images/book-covers/cover-7.svg',
    description: 'An authoritative technical survey of mathematical fundamentals and neural network architectures.'
  },
  {
    id: 'BK-1008',
    isbn: '978-0199535729',
    title: 'The Republic',
    author: 'Plato',
    authorId: 'AUT-08',
    category: 'Philosophy & Ethics',
    categoryId: 'CAT-07',
    publisher: 'Oxford World Classics',
    publicationYear: 2008,
    language: 'English',
    shelfNumber: 'PH-02-05',
    totalCopies: 6,
    availableCopies: 5,
    price: 13.95,
    coverImage: '/assets/images/book-covers/cover-8.svg',
    description: 'Plato examines the meaning of justice, the ideal state structure, and the philosopher ruler.'
  },
  {
    id: 'BK-1009',
    isbn: '978-1543813074',
    title: 'Constitutional Law: Principles and Policies',
    author: 'Erwin Chemerinsky',
    authorId: 'AUT-09',
    category: 'Law & Jurisprudence',
    categoryId: 'CAT-08',
    publisher: 'Aspen Publishers',
    publicationYear: 2019,
    language: 'English',
    shelfNumber: 'LW-01-19',
    totalCopies: 5,
    availableCopies: 3,
    price: 145.00,
    coverImage: '/assets/images/book-covers/cover-9.svg',
    description: 'The preeminent single-volume treatise explaining major American constitutional law doctrines.'
  },
  {
    id: 'BK-1010',
    isbn: '978-0374533557',
    title: 'Thinking, Fast and Slow',
    author: 'Daniel Kahneman',
    authorId: 'AUT-10',
    category: 'Behavioral Sciences',
    categoryId: 'CAT-09',
    publisher: 'Farrar, Straus and Giroux',
    publicationYear: 2013,
    language: 'English',
    shelfNumber: 'B-04-22',
    totalCopies: 8,
    availableCopies: 5,
    price: 19.99,
    coverImage: '/assets/images/book-covers/cover-10.svg',
    description: 'Two systems drive the way we think: System 1 is fast, intuitive, and emotional; System 2 is slower and deliberative.'
  },
  {
    id: 'BK-1011',
    isbn: '978-0131103627',
    title: 'The C Programming Language, 2nd Edition',
    author: 'Thomas H. Cormen',
    authorId: 'AUT-01',
    category: 'Computer Science',
    categoryId: 'CAT-01',
    publisher: 'Prentice Hall',
    publicationYear: 1988,
    language: 'English',
    shelfNumber: 'A-11-09',
    totalCopies: 6,
    availableCopies: 5,
    price: 65.00,
    coverImage: '/assets/images/book-covers/cover-1.svg',
    description: 'The definitive guide to ANSI standard C programming by the language designers.'
  },
  {
    id: 'BK-1012',
    isbn: '978-0141439587',
    title: 'Emma',
    author: 'Jane Austen',
    authorId: 'AUT-02',
    category: 'Literature & Fiction',
    categoryId: 'CAT-02',
    publisher: 'Penguin Classics',
    publicationYear: 2003,
    language: 'English',
    shelfNumber: 'L-04-20',
    totalCopies: 5,
    availableCopies: 4,
    price: 12.50,
    coverImage: '/assets/images/book-covers/cover-2.svg',
    description: 'A sparkling comedy of manners centered on the clever and confident Emma Woodhouse.'
  },
  {
    id: 'BK-1013',
    isbn: '978-0553109535',
    title: 'The Universe in a Nutshell',
    author: 'Dr. Stephen Hawking',
    authorId: 'AUT-03',
    category: 'Physical Sciences',
    categoryId: 'CAT-03',
    publisher: 'Bantam',
    publicationYear: 2001,
    language: 'English',
    shelfNumber: 'P-08-04',
    totalCopies: 4,
    availableCopies: 3,
    price: 35.00,
    coverImage: '/assets/images/book-covers/cover-3.svg',
    description: 'Supergravity, supersymmetry, quantum theory, M-theory, and the holographic universe explained.'
  },
  {
    id: 'BK-1014',
    isbn: '978-1337096560',
    title: 'Principles of Microeconomics',
    author: 'N. Gregory Mankiw',
    authorId: 'AUT-04',
    category: 'Economics & Finance',
    categoryId: 'CAT-04',
    publisher: 'Cengage',
    publicationYear: 2021,
    language: 'English',
    shelfNumber: 'E-03-12',
    totalCopies: 7,
    availableCopies: 6,
    price: 180.00,
    coverImage: '/assets/images/book-covers/cover-4.svg',
    description: 'Core microeconomic principles covering consumer utility, firm competition, and price equilibrium.'
  },
  {
    id: 'BK-1015',
    isbn: '978-0062464316',
    title: 'Homo Deus: A Brief History of Tomorrow',
    author: 'Yuval Noah Harari',
    authorId: 'AUT-05',
    category: 'World History',
    categoryId: 'CAT-05',
    publisher: 'Harper',
    publicationYear: 2017,
    language: 'English',
    shelfNumber: 'H-09-08',
    totalCopies: 6,
    availableCopies: 4,
    price: 26.50,
    coverImage: '/assets/images/book-covers/cover-5.svg',
    description: 'Yuval Noah Harari envisions our future as humanity seeks immortality, happiness, and godlike powers.'
  },
  {
    id: 'BK-1016',
    isbn: '978-1119598244',
    title: 'Microbiology: An Introduction',
    author: 'Gerard J. Tortora',
    authorId: 'AUT-06',
    category: 'Medical Sciences',
    categoryId: 'CAT-06',
    publisher: 'Pearson',
    publicationYear: 2020,
    language: 'English',
    shelfNumber: 'M-05-18',
    totalCopies: 5,
    availableCopies: 3,
    price: 175.00,
    coverImage: '/assets/images/book-covers/cover-6.svg',
    description: 'Presents complex microbiology concepts with clarity, clinical vignettes, and metabolic pathways.'
  },
  {
    id: 'BK-1017',
    isbn: '978-0262044844',
    title: 'Reinforcement Learning: An Introduction',
    author: 'Ian Goodfellow',
    authorId: 'AUT-07',
    category: 'Artificial Intelligence',
    categoryId: 'CAT-01',
    publisher: 'MIT Press',
    publicationYear: 2018,
    language: 'English',
    shelfNumber: 'A-14-04',
    totalCopies: 5,
    availableCopies: 2,
    price: 79.99,
    coverImage: '/assets/images/book-covers/cover-7.svg',
    description: 'The core foundations of reinforcement learning, Markov decision processes, and policy gradients.'
  },
  {
    id: 'BK-1018',
    isbn: '978-0199540525',
    title: 'Symposium and Phaedrus',
    author: 'Plato',
    authorId: 'AUT-08',
    category: 'Philosophy & Ethics',
    categoryId: 'CAT-07',
    publisher: 'Oxford World Classics',
    publicationYear: 2009,
    language: 'English',
    shelfNumber: 'PH-02-08',
    totalCopies: 4,
    availableCopies: 3,
    price: 14.50,
    coverImage: '/assets/images/book-covers/cover-8.svg',
    description: 'Discussions on the divine nature of love, desire, rhetoric, and philosophical contemplation.'
  },
  {
    id: 'BK-1019',
    isbn: '978-1454894650',
    title: 'Federal Jurisdiction, 8th Edition',
    author: 'Erwin Chemerinsky',
    authorId: 'AUT-09',
    category: 'Law & Jurisprudence',
    categoryId: 'CAT-08',
    publisher: 'Wolters Kluwer',
    publicationYear: 2020,
    language: 'English',
    shelfNumber: 'LW-01-22',
    totalCopies: 4,
    availableCopies: 2,
    price: 160.00,
    coverImage: '/assets/images/book-covers/cover-9.svg',
    description: 'In-depth analysis of Article III courts, judicial review, standing, and Eleventh Amendment immunity.'
  },
  {
    id: 'BK-1020',
    isbn: '978-0316492546',
    title: 'Noise: A Flaw in Human Judgment',
    author: 'Daniel Kahneman',
    authorId: 'AUT-10',
    category: 'Behavioral Sciences',
    categoryId: 'CAT-09',
    publisher: 'Little, Brown and Company',
    publicationYear: 2021,
    language: 'English',
    shelfNumber: 'B-04-26',
    totalCopies: 7,
    availableCopies: 4,
    price: 21.99,
    coverImage: '/assets/images/book-covers/cover-10.svg',
    description: 'Groundbreaking exploration of why people make wildly different judgments in law, medicine, and business.'
  },
  {
    id: 'BK-1021',
    isbn: '978-0132350884',
    title: 'Clean Code: A Handbook of Agile Software',
    author: 'Thomas H. Cormen',
    authorId: 'AUT-01',
    category: 'Computer Science',
    categoryId: 'CAT-01',
    publisher: 'Prentice Hall',
    publicationYear: 2008,
    language: 'English',
    shelfNumber: 'A-12-15',
    totalCopies: 8,
    availableCopies: 6,
    price: 52.00,
    coverImage: '/assets/images/book-covers/cover-1.svg',
    description: 'Best practices for software craftsmanship, refactoring, unit testing, and readable code.'
  },
  {
    id: 'BK-1022',
    isbn: '978-0141439662',
    title: 'Sense and Sensibility',
    author: 'Jane Austen',
    authorId: 'AUT-02',
    category: 'Literature & Fiction',
    categoryId: 'CAT-02',
    publisher: 'Penguin Classics',
    publicationYear: 2003,
    language: 'English',
    shelfNumber: 'L-04-25',
    totalCopies: 5,
    availableCopies: 4,
    price: 11.95,
    coverImage: '/assets/images/book-covers/cover-2.svg',
    description: 'The story of two sisters: prudent Elinor and passionate Marianne confronting 19th-century society.'
  },
  {
    id: 'BK-1023',
    isbn: '978-0553802023',
    title: 'The Grand Design',
    author: 'Dr. Stephen Hawking',
    authorId: 'AUT-03',
    category: 'Physical Sciences',
    categoryId: 'CAT-03',
    publisher: 'Bantam Books',
    publicationYear: 2010,
    language: 'English',
    shelfNumber: 'P-08-09',
    totalCopies: 6,
    availableCopies: 4,
    price: 28.00,
    coverImage: '/assets/images/book-covers/cover-3.svg',
    description: 'A revolutionary look at our universe, M-theory, and quantum physics without metaphysical necessity.'
  },
  {
    id: 'BK-1024',
    isbn: '978-1305971509',
    title: 'Economics, 8th Edition',
    author: 'N. Gregory Mankiw',
    authorId: 'AUT-04',
    category: 'Economics & Finance',
    categoryId: 'CAT-04',
    publisher: 'Cengage',
    publicationYear: 2017,
    language: 'English',
    shelfNumber: 'E-03-18',
    totalCopies: 5,
    availableCopies: 3,
    price: 220.00,
    coverImage: '/assets/images/book-covers/cover-4.svg',
    description: 'Comprehensive unified coverage of microeconomic fundamentals and macroeconomic policies.'
  },
  {
    id: 'BK-1025',
    isbn: '978-0525510611',
    title: '21 Lessons for the 21st Century',
    author: 'Yuval Noah Harari',
    authorId: 'AUT-05',
    category: 'World History',
    categoryId: 'CAT-05',
    publisher: 'Spiegel & Grau',
    publicationYear: 2018,
    language: 'English',
    shelfNumber: 'H-09-12',
    totalCopies: 6,
    availableCopies: 5,
    price: 23.50,
    coverImage: '/assets/images/book-covers/cover-5.svg',
    description: 'How to navigate the urgent political, technological, and existential issues of the present era.'
  },
  {
    id: 'BK-1026',
    isbn: '978-1496387790',
    title: 'Moore Clinically Oriented Anatomy',
    author: 'Gerard J. Tortora',
    authorId: 'AUT-06',
    category: 'Medical Sciences',
    categoryId: 'CAT-06',
    publisher: 'Wolters Kluwer',
    publicationYear: 2017,
    language: 'English',
    shelfNumber: 'M-05-22',
    totalCopies: 4,
    availableCopies: 2,
    price: 115.00,
    coverImage: '/assets/images/book-covers/cover-6.svg',
    description: 'World-renowned anatomy textbook guiding clinical evaluation and surgical correlations.'
  },
  {
    id: 'BK-1027',
    isbn: '978-0262039246',
    title: 'Foundations of Machine Learning',
    author: 'Ian Goodfellow',
    authorId: 'AUT-07',
    category: 'Artificial Intelligence',
    categoryId: 'CAT-01',
    publisher: 'MIT Press',
    publicationYear: 2018,
    language: 'English',
    shelfNumber: 'A-14-09',
    totalCopies: 5,
    availableCopies: 3,
    price: 75.00,
    coverImage: '/assets/images/book-covers/cover-7.svg',
    description: 'Theoretical foundations of PAC learning, kernel methods, generalization bounds, and Rademacher complexity.'
  },
  {
    id: 'BK-1028',
    isbn: '978-0199540532',
    title: 'Early Socratic Dialogues',
    author: 'Plato',
    authorId: 'AUT-08',
    category: 'Philosophy & Ethics',
    categoryId: 'CAT-07',
    publisher: 'Penguin Classics',
    publicationYear: 2005,
    language: 'English',
    shelfNumber: 'PH-02-12',
    totalCopies: 4,
    availableCopies: 4,
    price: 16.00,
    coverImage: '/assets/images/book-covers/cover-8.svg',
    description: 'Ion, Laches, Lysis, Charmides, Hippias Major, Euthydemus, and Protagoras in scholarly translation.'
  },
  {
    id: 'BK-1029',
    isbn: '978-1543807660',
    title: 'Criminal Procedure: Investigation',
    author: 'Erwin Chemerinsky',
    authorId: 'AUT-09',
    category: 'Law & Jurisprudence',
    categoryId: 'CAT-08',
    publisher: 'Aspen',
    publicationYear: 2021,
    language: 'English',
    shelfNumber: 'LW-01-29',
    totalCopies: 4,
    availableCopies: 3,
    price: 135.00,
    coverImage: '/assets/images/book-covers/cover-9.svg',
    description: 'Fourth, Fifth, and Sixth Amendment doctrines governing police search, interrogation, and right to counsel.'
  },
  {
    id: 'BK-1030',
    isbn: '978-0195159899',
    title: 'Choices, Values, and Frames',
    author: 'Daniel Kahneman',
    authorId: 'AUT-10',
    category: 'Behavioral Sciences',
    categoryId: 'CAT-09',
    publisher: 'Cambridge University Press',
    publicationYear: 2000,
    language: 'English',
    shelfNumber: 'B-04-30',
    totalCopies: 4,
    availableCopies: 3,
    price: 49.99,
    coverImage: '/assets/images/book-covers/cover-10.svg',
    description: 'Foundational papers on prospect theory, loss aversion, heuristic judgment, and framing effects.'
  },
  {
    id: 'BK-1031',
    isbn: '978-0134685991',
    title: 'Effective Java, 3rd Edition',
    author: 'Thomas H. Cormen',
    authorId: 'AUT-01',
    category: 'Computer Science',
    categoryId: 'CAT-01',
    publisher: 'Addison-Wesley',
    publicationYear: 2018,
    language: 'English',
    shelfNumber: 'A-12-22',
    totalCopies: 6,
    availableCopies: 5,
    price: 54.99,
    coverImage: '/assets/images/book-covers/cover-1.svg',
    description: 'Best practice guidelines for Java development, generics, enums, lambdas, streams, and concurrency.'
  },
  {
    id: 'BK-1032',
    isbn: '978-0141439686',
    title: 'Mansfield Park',
    author: 'Jane Austen',
    authorId: 'AUT-02',
    category: 'Literature & Fiction',
    categoryId: 'CAT-02',
    publisher: 'Penguin Classics',
    publicationYear: 2003,
    language: 'English',
    shelfNumber: 'L-04-32',
    totalCopies: 4,
    availableCopies: 3,
    price: 11.50,
    coverImage: '/assets/images/book-covers/cover-2.svg',
    description: 'Fanny Price, a poor relation brought up at Mansfield Park, must negotiate moral trials and love.'
  }
];

const SEED_MEMBERS = [
  {
    id: 'MEM-1001',
    fullName: 'Eleanor Vance',
    email: 'e.vance@athenaeum.edu',
    phone: '+1 (555) 234-9011',
    address: '14 Memorial Drive, Cambridge, MA',
    membershipType: 'Faculty',
    registrationDate: '2023-01-15',
    expiryDate: '2027-01-15',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-1.svg',
    maxLimit: 10
  },
  {
    id: 'MEM-1002',
    fullName: 'Marcus Chen',
    email: 'm.chen@athenaeum.edu',
    phone: '+1 (555) 492-3810',
    address: '88 Kirkland Street, Cambridge, MA',
    membershipType: 'Faculty',
    registrationDate: '2023-03-20',
    expiryDate: '2027-03-20',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-2.svg',
    maxLimit: 10
  },
  {
    id: 'MEM-1003',
    fullName: 'Sarah Jenkins',
    email: 'sarah.j@student.athenaeum.edu',
    phone: '+1 (555) 712-4491',
    address: '22 Peabody Terrace, Apt 4B, Cambridge, MA',
    membershipType: 'Student',
    registrationDate: '2024-09-01',
    expiryDate: '2028-06-30',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-3.svg',
    maxLimit: 5
  },
  {
    id: 'MEM-1004',
    fullName: 'David Ross',
    email: 'd.ross@alum.athenaeum.edu',
    phone: '+1 (555) 883-1205',
    address: '305 Beacon Street, Boston, MA',
    membershipType: 'Standard',
    registrationDate: '2022-11-10',
    expiryDate: '2026-11-10',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-4.svg',
    maxLimit: 5
  },
  {
    id: 'MEM-1005',
    fullName: 'Priya Patel',
    email: 'p.patel@research.athenaeum.edu',
    phone: '+1 (555) 301-9872',
    address: '15 Oxford Street, Cambridge, MA',
    membershipType: 'Faculty',
    registrationDate: '2023-08-14',
    expiryDate: '2027-08-14',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-5.svg',
    maxLimit: 10
  },
  {
    id: 'MEM-1006',
    fullName: 'Alexander Wright',
    email: 'a.wright@student.athenaeum.edu',
    phone: '+1 (555) 604-1188',
    address: '44 Garden Street, Cambridge, MA',
    membershipType: 'Student',
    registrationDate: '2023-09-01',
    expiryDate: '2027-06-30',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-4.svg',
    maxLimit: 5
  },
  {
    id: 'MEM-1007',
    fullName: 'Elena Rostova',
    email: 'e.rostova@student.athenaeum.edu',
    phone: '+1 (555) 554-3211',
    address: '71 Mount Auburn St, Cambridge, MA',
    membershipType: 'Student',
    registrationDate: '2024-02-10',
    expiryDate: '2028-06-30',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-3.svg',
    maxLimit: 5
  },
  {
    id: 'MEM-1008',
    fullName: 'Robert Sterling',
    email: 'r.sterling@public.library.org',
    phone: '+1 (555) 902-8419',
    address: '120 Commonwealth Ave, Boston, MA',
    membershipType: 'Standard',
    registrationDate: '2021-04-12',
    expiryDate: '2024-04-12',
    status: 'Expired',
    profileImage: '/assets/images/avatars/avatar-2.svg',
    maxLimit: 3
  },
  {
    id: 'MEM-1009',
    fullName: 'Amina Al-Mansoor',
    email: 'amina.m@postgrad.athenaeum.edu',
    phone: '+1 (555) 441-9032',
    address: '9 Concord Avenue, Cambridge, MA',
    membershipType: 'Premium',
    registrationDate: '2023-10-05',
    expiryDate: '2027-10-05',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-5.svg',
    maxLimit: 8
  },
  {
    id: 'MEM-1010',
    fullName: 'Liam O\'Connor',
    email: 'liam.oc@student.athenaeum.edu',
    phone: '+1 (555) 219-5830',
    address: '18 Everett Street, Cambridge, MA',
    membershipType: 'Student',
    registrationDate: '2024-01-20',
    expiryDate: '2028-06-30',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-4.svg',
    maxLimit: 5
  },
  {
    id: 'MEM-1011',
    fullName: 'Dr. Clara Thorne',
    email: 'c.thorne@med.athenaeum.edu',
    phone: '+1 (555) 380-7711',
    address: '200 Longwood Ave, Boston, MA',
    membershipType: 'Faculty',
    registrationDate: '2022-07-01',
    expiryDate: '2026-07-01',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-1.svg',
    maxLimit: 10
  },
  {
    id: 'MEM-1012',
    fullName: 'Julian Hayes',
    email: 'j.hayes@student.athenaeum.edu',
    phone: '+1 (555) 677-2294',
    address: '55 Linnaean Street, Cambridge, MA',
    membershipType: 'Student',
    registrationDate: '2023-09-15',
    expiryDate: '2027-06-30',
    status: 'Suspended',
    profileImage: '/assets/images/avatars/avatar-2.svg',
    maxLimit: 5
  },
  {
    id: 'MEM-1013',
    fullName: 'Grace Kim',
    email: 'grace.kim@design.athenaeum.edu',
    phone: '+1 (555) 412-0099',
    address: '48 Quincy Street, Cambridge, MA',
    membershipType: 'Student',
    registrationDate: '2024-09-01',
    expiryDate: '2028-06-30',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-3.svg',
    maxLimit: 5
  },
  {
    id: 'MEM-1014',
    fullName: 'Samuel Adebayo',
    email: 's.adebayo@student.athenaeum.edu',
    phone: '+1 (555) 843-2219',
    address: '10 DeWolfe Street, Cambridge, MA',
    membershipType: 'Student',
    registrationDate: '2023-09-01',
    expiryDate: '2027-06-30',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-4.svg',
    maxLimit: 5
  },
  {
    id: 'MEM-1015',
    fullName: 'Hannah Zimmerman',
    email: 'h.zimmerman@law.athenaeum.edu',
    phone: '+1 (555) 590-1123',
    address: '1563 Mass Ave, Cambridge, MA',
    membershipType: 'Student',
    registrationDate: '2023-08-25',
    expiryDate: '2026-05-30',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-5.svg',
    maxLimit: 6
  },
  {
    id: 'MEM-1016',
    fullName: 'Dr. Gregory Vance',
    email: 'gregory.v@physics.athenaeum.edu',
    phone: '+1 (555) 833-4011',
    address: '38 Waterhouse St, Cambridge, MA',
    membershipType: 'Faculty',
    registrationDate: '2021-09-01',
    expiryDate: '2028-09-01',
    status: 'Active',
    profileImage: '/assets/images/avatars/avatar-1.svg',
    maxLimit: 10
  }
];

const SEED_SUPPLIERS = [
  {
    id: 'SUP-01',
    companyName: 'Academic Book Consortium Ltd.',
    contactPerson: 'Jonathan Miller',
    email: 'orders@academicbooks.com',
    phone: '+1 (800) 555-0192',
    address: '100 University Plaza, New York, NY 10003',
    suppliedCategories: 'Computer Science, Physical Sciences, Medical Sciences',
    activeContracts: 4
  },
  {
    id: 'SUP-02',
    companyName: 'Cambridge University Press Global',
    contactPerson: 'Beatrice Ward',
    email: 'librarysales@cambridgepress.co.uk',
    phone: '+44 1223 358331',
    address: 'University Printing House, Shaftesbury Road, Cambridge CB2 8BS',
    suppliedCategories: 'Literature, Philosophy, History',
    activeContracts: 6
  },
  {
    id: 'SUP-03',
    companyName: 'Apex Educational Media Distributors',
    contactPerson: 'Rajiv Malhotra',
    email: 'institutional@apexedumedia.com',
    phone: '+1 (888) 420-9912',
    address: '740 Tech Parkway, Suite 300, Chicago, IL 60601',
    suppliedCategories: 'Economics & Finance, Law & Jurisprudence',
    activeContracts: 3
  },
  {
    id: 'SUP-04',
    companyName: 'Heritage Rare Books & Archives',
    contactPerson: 'Arthur Pendelton',
    email: 'curator@heritagerare.org',
    phone: '+1 (617) 555-8832',
    address: '82 Boylston Street, Boston, MA 02116',
    suppliedCategories: 'History & Archival Classics',
    activeContracts: 2
  },
  {
    id: 'SUP-05',
    companyName: 'SciTech Periodicals & Monographs',
    contactPerson: 'Dr. Linda Schultz',
    email: 'fulfillment@scitechmonographs.de',
    phone: '+49 30 20930',
    address: 'Unter den Linden 6, 10117 Berlin, Germany',
    suppliedCategories: 'Biochemistry, Quantum Physics, Machine Learning',
    activeContracts: 5
  }
];

const SEED_LOANS = [
  {
    id: 'TX-9001',
    bookId: 'BK-1007',
    bookTitle: 'Deep Learning',
    isbn: '978-0262035613',
    memberId: 'MEM-1003',
    memberName: 'Sarah Jenkins',
    issueDate: '2026-09-20',
    dueDate: '2026-10-04',
    returnDate: null,
    status: 'Overdue',
    overdueDays: 15,
    fineAmount: 7.50
  },
  {
    id: 'TX-9002',
    bookId: 'BK-1003',
    bookTitle: 'A Brief History of Time',
    isbn: '978-0553380163',
    memberId: 'MEM-1006',
    memberName: 'Alexander Wright',
    issueDate: '2026-09-28',
    dueDate: '2026-10-12',
    returnDate: null,
    status: 'Overdue',
    overdueDays: 7,
    fineAmount: 3.50
  },
  {
    id: 'TX-9003',
    bookId: 'BK-1001',
    bookTitle: 'Introduction to Algorithms, 4th Edition',
    isbn: '978-0262046305',
    memberId: 'MEM-1001',
    memberName: 'Eleanor Vance',
    issueDate: '2026-10-10',
    dueDate: '2026-10-24',
    returnDate: null,
    status: 'Issued',
    overdueDays: 0,
    fineAmount: 0.00
  },
  {
    id: 'TX-9004',
    bookId: 'BK-1006',
    bookTitle: 'Principles of Anatomy and Physiology',
    isbn: '978-1119704386',
    memberId: 'MEM-1005',
    memberName: 'Priya Patel',
    issueDate: '2026-10-14',
    dueDate: '2026-10-28',
    returnDate: null,
    status: 'Issued',
    overdueDays: 0,
    fineAmount: 0.00
  },
  {
    id: 'TX-9005',
    bookId: 'BK-1009',
    bookTitle: 'Constitutional Law: Principles and Policies',
    isbn: '978-1543813074',
    memberId: 'MEM-1015',
    memberName: 'Hannah Zimmerman',
    issueDate: '2026-10-16',
    dueDate: '2026-10-30',
    returnDate: null,
    status: 'Issued',
    overdueDays: 0,
    fineAmount: 0.00
  },
  {
    id: 'TX-9006',
    bookId: 'BK-1005',
    bookTitle: 'Sapiens: A Brief History of Humankind',
    isbn: '978-0062316097',
    memberId: 'MEM-1004',
    memberName: 'David Ross',
    issueDate: '2026-09-10',
    dueDate: '2026-09-24',
    returnDate: '2026-09-22',
    status: 'Returned',
    overdueDays: 0,
    fineAmount: 0.00
  },
  {
    id: 'TX-9007',
    bookId: 'BK-1010',
    bookTitle: 'Thinking, Fast and Slow',
    isbn: '978-0374533557',
    memberId: 'MEM-1009',
    memberName: 'Amina Al-Mansoor',
    issueDate: '2026-09-05',
    dueDate: '2026-09-19',
    returnDate: '2026-09-25',
    status: 'Returned',
    overdueDays: 6,
    fineAmount: 3.00
  }
];

const SEED_RESERVATIONS = [
  {
    id: 'RES-301',
    bookId: 'BK-1007',
    bookTitle: 'Deep Learning',
    memberId: 'MEM-1010',
    memberName: 'Liam O\'Connor',
    reservationDate: '2026-10-12',
    queuePosition: 1,
    status: 'Pending',
    notificationSent: false
  },
  {
    id: 'RES-302',
    bookId: 'BK-1007',
    bookTitle: 'Deep Learning',
    memberId: 'MEM-1014',
    memberName: 'Samuel Adebayo',
    reservationDate: '2026-10-15',
    queuePosition: 2,
    status: 'Pending',
    notificationSent: false
  },
  {
    id: 'RES-303',
    bookId: 'BK-1006',
    bookTitle: 'Principles of Anatomy and Physiology',
    memberId: 'MEM-1011',
    memberName: 'Dr. Clara Thorne',
    reservationDate: '2026-10-16',
    queuePosition: 1,
    status: 'Ready',
    notificationSent: true
  }
];

const SEED_FINES = [
  {
    id: 'FIN-501',
    transactionId: 'TX-9001',
    memberId: 'MEM-1003',
    memberName: 'Sarah Jenkins',
    bookTitle: 'Deep Learning',
    amount: 7.50,
    daysOverdue: 15,
    status: 'Unpaid',
    issuedDate: '2026-10-05',
    paidDate: null
  },
  {
    id: 'FIN-502',
    transactionId: 'TX-9002',
    memberId: 'MEM-1006',
    memberName: 'Alexander Wright',
    bookTitle: 'A Brief History of Time',
    amount: 3.50,
    daysOverdue: 7,
    status: 'Unpaid',
    issuedDate: '2026-10-13',
    paidDate: null
  },
  {
    id: 'FIN-503',
    transactionId: 'TX-9007',
    memberId: 'MEM-1009',
    memberName: 'Amina Al-Mansoor',
    bookTitle: 'Thinking, Fast and Slow',
    amount: 3.00,
    daysOverdue: 6,
    status: 'Paid',
    issuedDate: '2026-09-20',
    paidDate: '2026-09-25'
  }
];

const SEED_NOTIFICATIONS = [
  {
    id: 'NOTIF-1',
    title: 'Overdue Notice',
    message: 'Book "Deep Learning" borrowed by Sarah Jenkins is 15 days overdue. Fine accumulated: $7.50.',
    type: 'danger',
    timestamp: '2026-10-19T08:30:00Z',
    read: false,
    link: '/return-book.html?tx=TX-9001'
  },
  {
    id: 'NOTIF-2',
    title: 'Reservation Ready for Pickup',
    message: '"Principles of Anatomy and Physiology" is ready for Dr. Clara Thorne at Circulation Desk A.',
    type: 'success',
    timestamp: '2026-10-18T14:15:00Z',
    read: false,
    link: '/reservations.html'
  },
  {
    id: 'NOTIF-3',
    title: 'Low Stock Alert',
    message: 'Book "Deep Learning" has 0 available copies left in catalog.',
    type: 'warning',
    timestamp: '2026-10-17T11:00:00Z',
    read: true,
    link: '/books.html'
  },
  {
    id: 'NOTIF-4',
    title: 'Circulation Return Confirmed',
    message: 'David Ross returned "Sapiens: A Brief History of Humankind" in good condition.',
    type: 'info',
    timestamp: '2026-09-22T16:20:00Z',
    read: true,
    link: '/books.html'
  }
];

const SEED_CURRENT_USER = {
  id: 'USR-ADMIN',
  name: 'Eleanor Vance',
  email: 'e.vance@athenaeum.edu',
  role: 'Administrator', // 'Administrator' | 'Librarian' | 'Member'
  avatar: '/assets/images/avatars/avatar-1.svg',
  memberId: 'MEM-1001'
};

class StorageManager {
  static get(key, defaultValue = null) {
    try {
      const item = localStorage.getItem(key);
      if (item === null) return defaultValue;
      return JSON.parse(item);
    } catch (err) {
      console.warn(`Storage error reading ${key}:`, err);
      return defaultValue;
    }
  }

  static set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error(`Storage error writing ${key}:`, err);
      return false;
    }
  }

  static remove(key) {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (err) {
      console.error(`Storage error removing ${key}:`, err);
      return false;
    }
  }

  static initialize() {
    const isInitialized = this.get(STORAGE_KEYS.INITIALIZED, false);
    if (!isInitialized) {
      this.resetToDefaults();
    }
  }

  static resetToDefaults() {
    this.set(STORAGE_KEYS.BOOKS, SEED_BOOKS);
    this.set(STORAGE_KEYS.AUTHORS, SEED_AUTHORS);
    this.set(STORAGE_KEYS.CATEGORIES, SEED_CATEGORIES);
    this.set(STORAGE_KEYS.MEMBERS, SEED_MEMBERS);
    this.set(STORAGE_KEYS.SUPPLIERS, SEED_SUPPLIERS);
    this.set(STORAGE_KEYS.LOANS, SEED_LOANS);
    this.set(STORAGE_KEYS.RESERVATIONS, SEED_RESERVATIONS);
    this.set(STORAGE_KEYS.FINES, SEED_FINES);
    this.set(STORAGE_KEYS.NOTIFICATIONS, SEED_NOTIFICATIONS);
    this.set(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    this.set(STORAGE_KEYS.CURRENT_USER, SEED_CURRENT_USER);
    this.set(STORAGE_KEYS.INITIALIZED, true);
    console.info('Athenaeum demo data successfully initialized.');
  }

  // Collection Getters & Setters
  static getBooks() { return this.get(STORAGE_KEYS.BOOKS, []); }
  static saveBooks(books) { return this.set(STORAGE_KEYS.BOOKS, books); }

  static getAuthors() { return this.get(STORAGE_KEYS.AUTHORS, []); }
  static saveAuthors(authors) { return this.set(STORAGE_KEYS.AUTHORS, authors); }

  static getCategories() { return this.get(STORAGE_KEYS.CATEGORIES, []); }
  static saveCategories(cats) { return this.set(STORAGE_KEYS.CATEGORIES, cats); }

  static getMembers() { return this.get(STORAGE_KEYS.MEMBERS, []); }
  static saveMembers(members) { return this.set(STORAGE_KEYS.MEMBERS, members); }

  static getSuppliers() { return this.get(STORAGE_KEYS.SUPPLIERS, []); }
  static saveSuppliers(suppliers) { return this.set(STORAGE_KEYS.SUPPLIERS, suppliers); }

  static getLoans() { return this.get(STORAGE_KEYS.LOANS, []); }
  static saveLoans(loans) { return this.set(STORAGE_KEYS.LOANS, loans); }

  static getReservations() { return this.get(STORAGE_KEYS.RESERVATIONS, []); }
  static saveReservations(res) { return this.set(STORAGE_KEYS.RESERVATIONS, res); }

  static getFines() { return this.get(STORAGE_KEYS.FINES, []); }
  static saveFines(fines) { return this.set(STORAGE_KEYS.FINES, fines); }

  static getNotifications() { return this.get(STORAGE_KEYS.NOTIFICATIONS, []); }
  static saveNotifications(notifs) { return this.set(STORAGE_KEYS.NOTIFICATIONS, notifs); }

  static getSettings() { return this.get(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS); }
  static saveSettings(settings) { return this.set(STORAGE_KEYS.SETTINGS, settings); }

  static getCurrentUser() { return this.get(STORAGE_KEYS.CURRENT_USER, SEED_CURRENT_USER); }
  static setCurrentUser(user) { return this.set(STORAGE_KEYS.CURRENT_USER, user); }

  static getTheme() { return this.get(STORAGE_KEYS.THEME, 'light'); }
  static setTheme(theme) { return this.set(STORAGE_KEYS.THEME, theme); }
}

// Auto-initialize storage on load
StorageManager.initialize();

// Expose globally for vanilla scripts
window.StorageManager = StorageManager;
window.STORAGE_KEYS = STORAGE_KEYS;
