/**
 * Athenaeum Member Management Controller
 * Member registration, search, status toggling, and history routing
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('members-page-container')) {
    MembersController.init();
  }
});

const MembersController = {
  editingId: null,
  statusFilter: 'all',
  typeFilter: 'all',

  init() {
    this.bindEvents();
    this.render();
  },

  bindEvents() {
    const searchInput = document.getElementById('member-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', window.Utils.debounce(() => this.render(), 250));
    }

    const statusSel = document.getElementById('member-status-filter');
    if (statusSel) {
      statusSel.addEventListener('change', (e) => {
        this.statusFilter = e.target.value;
        this.render();
      });
    }

    const typeSel = document.getElementById('member-type-filter');
    if (typeSel) {
      typeSel.addEventListener('change', (e) => {
        this.typeFilter = e.target.value;
        this.render();
      });
    }

    const openAddBtn = document.getElementById('open-add-member-btn');
    const modalCloseBtn = document.getElementById('member-modal-close');
    const modalCancelBtn = document.getElementById('member-modal-cancel');
    const form = document.getElementById('member-form');

    if (openAddBtn) {
      openAddBtn.addEventListener('click', () => this.openAddModal());
    }
    if (modalCloseBtn) {
      modalCloseBtn.addEventListener('click', () => this.closeModal());
    }
    if (modalCancelBtn) {
      modalCancelBtn.addEventListener('click', () => this.closeModal());
    }
    if (form) {
      form.addEventListener('submit', (e) => this.handleFormSubmit(e));
    }
  },

  render() {
    const tableBody = document.getElementById('members-table-body');
    if (!tableBody) return;

    let members = window.StorageManager.getMembers();
    const searchInput = document.getElementById('member-search-input');
    const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

    if (q) {
      members = members.filter(m => 
        (m.id && m.id.toLowerCase().includes(q)) ||
        (m.fullName && m.fullName.toLowerCase().includes(q)) ||
        (m.email && m.email.toLowerCase().includes(q)) ||
        (m.phone && m.phone.toLowerCase().includes(q))
      );
    }

    if (this.statusFilter !== 'all') {
      members = members.filter(m => m.status === this.statusFilter);
    }

    if (this.typeFilter !== 'all') {
      members = members.filter(m => m.membershipType === this.typeFilter);
    }

    const countEl = document.getElementById('members-count-badge');
    if (countEl) countEl.textContent = `${members.length} members`;

    if (members.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="6" style="text-align: center; padding: 2.5rem; color: var(--text-muted);">
            No members found matching your search and filter criteria.
          </td>
        </tr>
      `;
      return;
    }

    const loans = window.StorageManager.getLoans();

    tableBody.innerHTML = members.map(m => {
      // Find active loans for this member
      const activeMemberLoans = loans.filter(l => l.memberId === m.id && !l.returnDate);
      const maxLimit = m.maxLimit || (m.membershipType === 'Faculty' ? 10 : 5);

      let statusBadge = 'badge-success';
      if (m.status === 'Suspended') statusBadge = 'badge-danger';
      if (m.status === 'Expired') statusBadge = 'badge-warning';

      return `
        <tr>
          <td>
            <div class="table-user-cell">
              <img src="${m.profileImage}" alt="${window.Utils.escapeHTML(m.fullName)}" class="table-user-thumb" />
              <div>
                <a href="/member-details.html?id=${m.id}" class="table-primary-text">${window.Utils.escapeHTML(m.fullName)}</a>
                <div class="table-secondary-text font-mono">${window.Utils.escapeHTML(m.id)}</div>
              </div>
            </div>
          </td>
          <td>
            <div>${window.Utils.escapeHTML(m.email)}</div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">${window.Utils.escapeHTML(m.phone)}</div>
          </td>
          <td>
            <span class="badge badge-neutral">${window.Utils.escapeHTML(m.membershipType)}</span>
          </td>
          <td class="tabular-nums">
            <strong>${activeMemberLoans.length}</strong> / ${maxLimit} borrowed
          </td>
          <td>
            <span class="badge ${statusBadge}">${window.Utils.escapeHTML(m.status)}</span>
          </td>
          <td class="text-right">
            <div class="table-actions">
              <a href="/member-details.html?id=${m.id}" class="action-icon-btn" title="View Details">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              </a>
              <button class="action-icon-btn" onclick="MembersController.openEditModal('${m.id}')" title="Edit Member">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
              <button class="action-icon-btn" onclick="MembersController.toggleStatus('${m.id}')" title="${m.status === 'Active' ? 'Suspend Member' : 'Activate Member'}">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openAddModal() {
    this.editingId = null;
    const modal = document.getElementById('member-modal');
    const title = document.getElementById('member-modal-title');
    const form = document.getElementById('member-form');

    if (modal && title && form) {
      title.textContent = 'Register New Member';
      form.reset();
      window.Validation.clearAllErrors(form);
      document.getElementById('member-form-avatar').value = '/assets/images/avatars/avatar-3.svg';
      document.getElementById('member-form-status').value = 'Active';
      modal.classList.add('active');
    }
  },

  openEditModal(memberId) {
    this.editingId = memberId;
    const members = window.StorageManager.getMembers();
    const member = members.find(m => m.id === memberId);
    if (!member) return;

    const modal = document.getElementById('member-modal');
    const title = document.getElementById('member-modal-title');
    const form = document.getElementById('member-form');

    if (modal && title && form) {
      title.textContent = `Edit Member: ${member.fullName}`;
      window.Validation.clearAllErrors(form);

      document.getElementById('member-form-name').value = member.fullName || '';
      document.getElementById('member-form-email').value = member.email || '';
      document.getElementById('member-form-phone').value = member.phone || '';
      document.getElementById('member-form-address').value = member.address || '';
      document.getElementById('member-form-type').value = member.membershipType || 'Student';
      document.getElementById('member-form-status').value = member.status || 'Active';
      document.getElementById('member-form-avatar').value = member.profileImage || '/assets/images/avatars/avatar-3.svg';

      modal.classList.add('active');
    }
  },

  closeModal() {
    const modal = document.getElementById('member-modal');
    if (modal) modal.classList.remove('active');
    this.editingId = null;
  },

  handleFormSubmit(e) {
    e.preventDefault();
    const form = document.getElementById('member-form');
    window.Validation.clearAllErrors(form);

    const nameInput = document.getElementById('member-form-name');
    const emailInput = document.getElementById('member-form-email');
    const phoneInput = document.getElementById('member-form-phone');
    const addressInput = document.getElementById('member-form-address');
    const typeInput = document.getElementById('member-form-type');
    const statusInput = document.getElementById('member-form-status');
    const avatarInput = document.getElementById('member-form-avatar');

    let isValid = true;

    if (!nameInput.value.trim()) {
      window.Validation.setFieldError(nameInput, 'Full name is required');
      isValid = false;
    }

    const email = emailInput.value.trim();
    if (!email) {
      window.Validation.setFieldError(emailInput, 'Email address is required');
      isValid = false;
    } else if (!window.Validation.isValidEmail(email)) {
      window.Validation.setFieldError(emailInput, 'Please enter a valid email address');
      isValid = false;
    }

    if (!phoneInput.value.trim()) {
      window.Validation.setFieldError(phoneInput, 'Phone number is required');
      isValid = false;
    }

    if (!isValid) return;

    const members = window.StorageManager.getMembers();

    // Check duplicate email
    const duplicate = members.some(m => 
      m.id !== this.editingId && m.email.toLowerCase() === email.toLowerCase()
    );
    if (duplicate) {
      window.Validation.setFieldError(emailInput, 'A member with this email already exists');
      return;
    }

    if (this.editingId) {
      const idx = members.findIndex(m => m.id === this.editingId);
      if (idx !== -1) {
        members[idx] = {
          ...members[idx],
          fullName: nameInput.value.trim(),
          email: email,
          phone: phoneInput.value.trim(),
          address: addressInput.value.trim(),
          membershipType: typeInput.value,
          status: statusInput.value,
          profileImage: avatarInput.value,
          maxLimit: typeInput.value === 'Faculty' ? 10 : 5
        };
        window.StorageManager.saveMembers(members);
        window.Utils.showToast('Member profile updated', 'success');
      }
    } else {
      const newId = window.Utils.generateId('MEM', members);
      members.push({
        id: newId,
        fullName: nameInput.value.trim(),
        email: email,
        phone: phoneInput.value.trim(),
        address: addressInput.value.trim() || 'Cambridge Campus Residence',
        membershipType: typeInput.value,
        registrationDate: window.Utils.getTodayString(),
        expiryDate: window.Utils.addDays(window.Utils.getTodayString(), 365 * 3),
        status: statusInput.value || 'Active',
        profileImage: avatarInput.value || '/assets/images/avatars/avatar-3.svg',
        maxLimit: typeInput.value === 'Faculty' ? 10 : 5
      });
      window.StorageManager.saveMembers(members);
      window.Utils.showToast('Member registered successfully', 'success');
    }

    this.closeModal();
    this.render();
  },

  toggleStatus(memberId) {
    const members = window.StorageManager.getMembers();
    const member = members.find(m => m.id === memberId);
    if (!member) return;

    const newStatus = member.status === 'Active' ? 'Suspended' : 'Active';
    member.status = newStatus;
    window.StorageManager.saveMembers(members);
    window.Utils.showToast(`Member status changed to ${newStatus}`, 'info');
    this.render();
  }
};

window.MembersController = MembersController;
