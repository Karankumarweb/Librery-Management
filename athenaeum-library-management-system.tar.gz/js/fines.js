/**
 * Athenaeum Fine Management Controller
 * Overdue penalty calculations, fine status tracking, and simulated payments
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('fines-page-container')) {
    FinesController.init();
  }
});

const FinesController = {
  statusFilter: 'all',

  init() {
    this.bindEvents();
    this.render();
  },

  bindEvents() {
    const searchInput = document.getElementById('fine-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', window.Utils.debounce(() => this.render(), 250));
    }

    const filterSel = document.getElementById('fine-status-filter');
    if (filterSel) {
      filterSel.addEventListener('change', (e) => {
        this.statusFilter = e.target.value;
        this.render();
      });
    }

    const receiptClose = document.getElementById('fine-receipt-close');
    if (receiptClose) {
      receiptClose.addEventListener('click', () => {
        document.getElementById('fine-receipt-modal').classList.remove('active');
      });
    }
  },

  render() {
    const tableBody = document.getElementById('fines-table-body');
    if (!tableBody) return;

    let fines = window.StorageManager.getFines();
    const searchInput = document.getElementById('fine-search-input');
    const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

    if (q) {
      fines = fines.filter(f => 
        f.id.toLowerCase().includes(q) ||
        f.memberName.toLowerCase().includes(q) ||
        f.memberId.toLowerCase().includes(q) ||
        f.bookTitle.toLowerCase().includes(q)
      );
    }

    if (this.statusFilter !== 'all') {
      fines = fines.filter(f => f.status === this.statusFilter);
    }

    // Update KPI counters
    const allFines = window.StorageManager.getFines();
    const unpaidTotal = allFines.filter(f => f.status === 'Unpaid').reduce((a, b) => a + (b.amount || 0), 0);
    const paidTotal = allFines.filter(f => f.status === 'Paid').reduce((a, b) => a + (b.amount || 0), 0);

    const unpaidCountEl = document.getElementById('fines-unpaid-sum');
    const paidCountEl = document.getElementById('fines-paid-sum');
    if (unpaidCountEl) unpaidCountEl.textContent = window.Utils.formatCurrency(unpaidTotal);
    if (paidCountEl) paidCountEl.textContent = window.Utils.formatCurrency(paidTotal);

    if (fines.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 2.5rem; color: var(--text-muted);">
            No fine records match your criteria.
          </td>
        </tr>
      `;
      return;
    }

    tableBody.innerHTML = fines.map(f => {
      const isPaid = f.status === 'Paid';

      return `
        <tr>
          <td class="font-mono tabular-nums" style="font-weight: 600;">${f.id}</td>
          <td>
            <div style="font-weight: 600; color: var(--text-main);">${window.Utils.escapeHTML(f.bookTitle)}</div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">Ref: ${f.transactionId}</div>
          </td>
          <td>
            <div>${window.Utils.escapeHTML(f.memberName)}</div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">${f.memberId}</div>
          </td>
          <td class="tabular-nums">${f.daysOverdue} days late</td>
          <td class="tabular-nums" style="font-weight: 700; color: ${isPaid ? 'var(--text-main)' : 'var(--danger)'};">
            ${window.Utils.formatCurrency(f.amount)}
          </td>
          <td>
            <span class="badge ${isPaid ? 'badge-success' : 'badge-danger'}">${f.status}</span>
            ${isPaid && f.paidDate ? `<div style="font-size: 0.6875rem; color: var(--text-muted); margin-top: 0.125rem;">Paid on ${window.Utils.formatDate(f.paidDate)}</div>` : ''}
          </td>
          <td class="text-right">
            ${!isPaid ? `
              <button class="btn btn-primary btn-sm" onclick="FinesController.payFine('${f.id}')">
                Pay Fine (Simulated)
              </button>
            ` : `
              <button class="btn btn-secondary btn-sm" onclick="FinesController.showReceipt('${f.id}')">
                Receipt
              </button>
            `}
          </td>
        </tr>
      `;
    }).join('');
  },

  payFine(fineId) {
    const fines = window.StorageManager.getFines();
    const fine = fines.find(f => f.id === fineId);
    if (!fine) return;

    if (fine.status === 'Paid') {
      window.Utils.showToast('This fine has already been marked as paid.', 'info');
      return;
    }

    window.Utils.confirmDialog({
      title: 'Record Simulated Fine Payment',
      message: `Accept simulated payment of ${window.Utils.formatCurrency(fine.amount)} for "${fine.bookTitle}" (${fine.memberName})?`,
      confirmText: 'Record Payment',
      onConfirm: () => {
        fine.status = 'Paid';
        fine.paidDate = window.Utils.getTodayString();
        window.StorageManager.saveFines(fines);

        // Add notification
        const notifs = window.StorageManager.getNotifications();
        notifs.unshift({
          id: window.Utils.generateId('NOTIF', notifs),
          title: 'Fine Payment Received',
          message: `Simulated payment of ${window.Utils.formatCurrency(fine.amount)} recorded for ${fine.memberName}.`,
          type: 'success',
          timestamp: new Date().toISOString(),
          read: false,
          link: '/fines.html'
        });
        window.StorageManager.saveNotifications(notifs);

        window.Utils.showToast('Fine payment recorded successfully', 'success');
        this.render();
        this.showReceipt(fine.id);
      }
    });
  },

  showReceipt(fineId) {
    const fines = window.StorageManager.getFines();
    const fine = fines.find(f => f.id === fineId);
    if (!fine) return;

    const modal = document.getElementById('fine-receipt-modal');
    const content = document.getElementById('fine-receipt-content');
    if (!modal || !content) return;

    content.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.25rem; border-bottom: 1px dashed var(--border-strong); padding-bottom: 1rem;">
        <h4 style="font-size: 1.125rem; font-weight: 700; color: var(--text-main);">ATHENAEUM UNIVERSITY LIBRARY</h4>
        <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Official Overdue Penalty Payment Receipt</div>
        <div style="font-size: 0.8125rem; font-family: var(--font-mono); font-weight: 700; color: var(--accent-500); margin-top: 0.5rem;">
          Receipt Reference #${fine.id}
        </div>
      </div>

      <div style="display: flex; flex-direction: column; gap: 0.5rem; font-size: 0.875rem;">
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Patron:</span>
          <strong>${window.Utils.escapeHTML(fine.memberName)} (${fine.memberId})</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Item Title:</span>
          <span style="max-width: 250px; text-align: right;">${window.Utils.escapeHTML(fine.bookTitle)}</span>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Circulation Ref:</span>
          <span class="font-mono">${fine.transactionId}</span>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Days Overdue:</span>
          <span>${fine.daysOverdue} days</span>
        </div>
        <div style="display: flex; justify-content: space-between; border-top: 1px solid var(--border-subtle); padding-top: 0.5rem;">
          <span style="font-weight: 700;">Amount Paid:</span>
          <strong style="color: var(--success); font-size: 1.125rem;">${window.Utils.formatCurrency(fine.amount)}</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Payment Date:</span>
          <span>${window.Utils.formatDate(fine.paidDate || window.Utils.getTodayString())}</span>
        </div>
      </div>

      <div style="margin-top: 1.25rem; padding: 0.75rem; background-color: var(--bg-subtle); border-radius: var(--radius-md); font-size: 0.75rem; color: var(--text-muted); text-align: center;">
        Note: Simulated transaction generated by frontend system. No actual credit card or bank funds were processed.
      </div>
    `;

    modal.classList.add('active');
  }
};

window.FinesController = FinesController;
