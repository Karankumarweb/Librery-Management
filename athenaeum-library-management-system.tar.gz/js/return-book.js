/**
 * Athenaeum Circulation: Return Book Controller
 * Return processing, automated inventory increment, overdue fine calculation, and reservation queue notification
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('return-book-page-container')) {
    ReturnBookController.init();
  }
});

const ReturnBookController = {
  activeLoans: [],
  selectedLoan: null,

  init() {
    this.bindEvents();
    this.loadActiveLoans();
    this.checkUrlPreselect();
  },

  loadActiveLoans() {
    const loans = window.StorageManager.getLoans();
    // Only active loans can be returned
    this.activeLoans = loans.filter(l => !l.returnDate);
    this.renderActiveLoansList(this.activeLoans);
  },

  checkUrlPreselect() {
    const params = new URLSearchParams(window.location.search);
    const tx = params.get('tx');
    if (tx) {
      const match = this.activeLoans.find(l => l.id === tx);
      if (match) {
        this.selectLoanForReturn(match);
      }
    }
  },

  bindEvents() {
    const searchInput = document.getElementById('return-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', window.Utils.debounce((e) => {
        const q = e.target.value.trim().toLowerCase();
        const filtered = this.activeLoans.filter(l => 
          l.id.toLowerCase().includes(q) ||
          l.memberId.toLowerCase().includes(q) ||
          l.memberName.toLowerCase().includes(q) ||
          l.bookTitle.toLowerCase().includes(q) ||
          l.isbn.toLowerCase().includes(q)
        );
        this.renderActiveLoansList(filtered);
      }, 250));
    }

    const processBtn = document.getElementById('process-return-btn');
    if (processBtn) {
      processBtn.addEventListener('click', () => this.handleProcessReturn());
    }

    const closeReceipt = document.getElementById('return-receipt-close');
    if (closeReceipt) {
      closeReceipt.addEventListener('click', () => {
        document.getElementById('return-receipt-modal').classList.remove('active');
        window.location.reload();
      });
    }
  },

  renderActiveLoansList(loans) {
    const container = document.getElementById('active-loans-list');
    if (!container) return;

    if (loans.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <h4 style="font-size: 1rem; font-weight: 700; color: var(--text-main);">No Active Borrowing Matches</h4>
          <p class="empty-desc">All books in this criteria have already been returned or none exist.</p>
        </div>
      `;
      return;
    }

    const todayStr = window.Utils.getTodayString();

    container.innerHTML = loans.map(loan => {
      const overdueDays = window.Utils.calculateOverdueDays(loan.dueDate, todayStr);
      const isOverdue = overdueDays > 0;

      return `
        <div class="card" style="margin-bottom: 0.875rem; cursor: pointer; transition: all var(--transition-fast);" 
             onclick="ReturnBookController.selectLoanForReturn('${loan.id}')">
          <div class="card-body" style="padding: 1rem 1.25rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem;">
            <div>
              <div style="display: flex; align-items: center; gap: 0.5rem;">
                <span class="font-mono" style="font-weight: 700; font-size: 0.8125rem; color: var(--accent-500);">${loan.id}</span>
                <span class="badge ${isOverdue ? 'badge-danger' : 'badge-info'}">
                  ${isOverdue ? `${overdueDays} Days Overdue` : 'Current Loan'}
                </span>
              </div>
              <div style="font-weight: 700; color: var(--text-main); font-size: 0.9375rem; margin-top: 0.25rem;">
                ${window.Utils.escapeHTML(loan.bookTitle)}
              </div>
              <div style="font-size: 0.8125rem; color: var(--text-muted); margin-top: 0.125rem;">
                Borrower: <strong>${window.Utils.escapeHTML(loan.memberName)}</strong> (${loan.memberId})
              </div>
            </div>

            <div style="text-align: right;">
              <div style="font-size: 0.75rem; color: var(--text-muted);">Due Date</div>
              <div class="tabular-nums" style="font-weight: 600; font-size: 0.875rem; color: ${isOverdue ? 'var(--danger)' : 'var(--text-main)'};">
                ${window.Utils.formatDate(loan.dueDate)}
              </div>
              <button class="btn btn-secondary btn-sm" style="margin-top: 0.375rem;">
                Select for Return
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  selectLoanForReturn(loanOrId) {
    let loan = typeof loanOrId === 'string' 
      ? this.activeLoans.find(l => l.id === loanOrId) 
      : loanOrId;

    if (!loan) return;
    this.selectedLoan = loan;

    const detailsBox = document.getElementById('return-calculation-box');
    const emptyNotice = document.getElementById('return-empty-selection');
    if (!detailsBox) return;

    if (emptyNotice) emptyNotice.style.display = 'none';
    detailsBox.style.display = 'block';

    const todayStr = window.Utils.getTodayString();
    const settings = window.StorageManager.getSettings();
    const dailyRate = settings.dailyFineRate || 0.50;

    const overdueDays = window.Utils.calculateOverdueDays(loan.dueDate, todayStr);
    const fineAmount = overdueDays * dailyRate;

    // Render Calculation Details
    document.getElementById('calc-tx-id').textContent = loan.id;
    document.getElementById('calc-book-title').textContent = loan.bookTitle;
    document.getElementById('calc-isbn').textContent = loan.isbn;
    document.getElementById('calc-member-name').textContent = `${loan.memberName} (${loan.memberId})`;
    document.getElementById('calc-issue-date').textContent = window.Utils.formatDate(loan.issueDate);
    document.getElementById('calc-due-date').textContent = window.Utils.formatDate(loan.dueDate);
    document.getElementById('calc-return-date').textContent = window.Utils.formatDate(todayStr);

    const overdueBadge = document.getElementById('calc-overdue-days');
    if (overdueBadge) {
      if (overdueDays > 0) {
        overdueBadge.innerHTML = `<span class="badge badge-danger">${overdueDays} Day(s) Overdue</span>`;
      } else {
        overdueBadge.innerHTML = `<span class="badge badge-success">On-Time Return</span>`;
      }
    }

    const fineAmountEl = document.getElementById('calc-fine-amount');
    if (fineAmountEl) {
      fineAmountEl.textContent = window.Utils.formatCurrency(fineAmount);
      fineAmountEl.style.color = fineAmount > 0 ? 'var(--danger)' : 'var(--success)';
    }

    // Scroll to action panel on mobile
    detailsBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  },

  handleProcessReturn() {
    if (!this.selectedLoan) {
      window.Utils.showToast('Please select an active loan transaction to return.', 'warning');
      return;
    }

    // Business Rule 9: Prevent duplicate returns
    const loans = window.StorageManager.getLoans();
    const loanIndex = loans.findIndex(l => l.id === this.selectedLoan.id);
    if (loanIndex === -1 || loans[loanIndex].returnDate) {
      window.Utils.showToast('This loan has already been closed and returned.', 'danger');
      return;
    }

    const todayStr = window.Utils.getTodayString();
    const settings = window.StorageManager.getSettings();
    const dailyRate = settings.dailyFineRate || 0.50;

    const overdueDays = window.Utils.calculateOverdueDays(this.selectedLoan.dueDate, todayStr);
    const fineAmount = overdueDays * dailyRate;

    // 1. Update Loan status
    loans[loanIndex].returnDate = todayStr;
    loans[loanIndex].status = 'Returned';
    loans[loanIndex].overdueDays = overdueDays;
    loans[loanIndex].fineAmount = fineAmount;
    window.StorageManager.saveLoans(loans);

    // 2. Business Rule 3: Automatically increase available copies (bounded by totalCopies)
    const books = window.StorageManager.getBooks();
    const bookIndex = books.findIndex(b => b.id === this.selectedLoan.bookId);
    if (bookIndex !== -1) {
      const curAvail = parseInt(books[bookIndex].availableCopies, 10);
      const total = parseInt(books[bookIndex].totalCopies, 10);
      books[bookIndex].availableCopies = Math.min(total, curAvail + 1);
      window.StorageManager.saveBooks(books);
    }

    // 3. Create Fine record if overdue
    let fineRecord = null;
    if (fineAmount > 0) {
      const fines = window.StorageManager.getFines();
      fineRecord = {
        id: window.Utils.generateId('FIN', fines),
        transactionId: this.selectedLoan.id,
        memberId: this.selectedLoan.memberId,
        memberName: this.selectedLoan.memberName,
        bookTitle: this.selectedLoan.bookTitle,
        amount: fineAmount,
        daysOverdue: overdueDays,
        status: 'Unpaid',
        issuedDate: todayStr,
        paidDate: null
      };
      fines.unshift(fineRecord);
      window.StorageManager.saveFines(fines);
    }

    // 4. Check Reservation Queue for this book
    const reservations = window.StorageManager.getReservations();
    const pendingForBook = reservations
      .filter(r => r.bookId === this.selectedLoan.bookId && r.status === 'Pending')
      .sort((a, b) => a.queuePosition - b.queuePosition);

    if (pendingForBook.length > 0) {
      // Mark top reservation as 'Ready'
      const topRes = pendingForBook[0];
      const rIdx = reservations.findIndex(r => r.id === topRes.id);
      if (rIdx !== -1) {
        reservations[rIdx].status = 'Ready';
        reservations[rIdx].notificationSent = true;
        window.StorageManager.saveReservations(reservations);

        // Add notification
        const notifs = window.StorageManager.getNotifications();
        notifs.unshift({
          id: window.Utils.generateId('NOTIF', notifs),
          title: 'Reserved Book Now Available',
          message: `"${this.selectedLoan.bookTitle}" is now ready for pickup by ${topRes.memberName}.`,
          type: 'success',
          timestamp: new Date().toISOString(),
          read: false,
          link: '/reservations.html'
        });
        window.StorageManager.saveNotifications(notifs);
      }
    }

    window.Utils.showToast('Book return processed successfully!', 'success');

    // Show Confirmation Receipt
    this.showReturnReceipt(this.selectedLoan, overdueDays, fineAmount);
  },

  showReturnReceipt(loan, overdueDays, fineAmount) {
    const modal = document.getElementById('return-receipt-modal');
    const content = document.getElementById('return-receipt-content');
    if (!modal || !content) return;

    content.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.25rem; border-bottom: 1px dashed var(--border-strong); padding-bottom: 1rem;">
        <h4 style="font-size: 1.125rem; font-weight: 700; color: var(--text-main);">ATHENAEUM UNIVERSITY LIBRARY</h4>
        <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Circulation Book Return Acknowledgement</div>
        <div style="font-size: 0.8125rem; font-family: var(--font-mono); font-weight: 700; color: var(--success); margin-top: 0.5rem;">
          Return Confirmation #${loan.id}
        </div>
      </div>

      <div style="display: flex; flex-direction: column; gap: 0.5rem; font-size: 0.875rem;">
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Book Title:</span>
          <strong>${window.Utils.escapeHTML(loan.bookTitle)}</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Borrower:</span>
          <span>${window.Utils.escapeHTML(loan.memberName)} (${loan.memberId})</span>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Return Date:</span>
          <span>${window.Utils.formatDate(window.Utils.getTodayString())}</span>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Overdue Status:</span>
          <strong>${overdueDays > 0 ? `${overdueDays} days late` : 'On Time'}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; padding-top: 0.5rem; border-top: 1px solid var(--border-subtle);">
          <span style="font-weight: 700;">Overdue Fine:</span>
          <strong style="color: ${fineAmount > 0 ? 'var(--danger)' : 'var(--success)'};">
            ${window.Utils.formatCurrency(fineAmount)}
          </strong>
        </div>
      </div>

      ${fineAmount > 0 ? `
        <div style="margin-top: 1.25rem; padding: 0.75rem; background-color: var(--warning-bg); border: 1px solid var(--warning-border); border-radius: var(--radius-md); font-size: 0.75rem; color: var(--warning); text-align: center;">
          An unpaid fine of ${window.Utils.formatCurrency(fineAmount)} has been registered to the member account.
        </div>
      ` : ''}
    `;

    modal.classList.add('active');
  }
};

window.ReturnBookController = ReturnBookController;
