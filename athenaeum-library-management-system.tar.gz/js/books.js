/**
 * Athenaeum Book Management Controller
 * Catalog search, filtering, grid/table view, pagination, Add/Edit/Delete modals
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('books-page-container')) {
    BooksController.init();
  }
});

const BooksController = {
  currentView: 'grid', // 'grid' | 'table'
  currentPage: 1,
  pageSize: 8,
  searchQuery: '',
  selectedCategory: 'all',
  selectedAvailability: 'all',
  sortBy: 'title-asc',
  editingBookId: null,

  init() {
    this.readUrlParams();
    this.populateCategoryDropdown();
    this.bindEvents();
    this.render();
  },

  readUrlParams() {
    const params = new URLSearchParams(window.location.search);
    if (params.has('search')) {
      this.searchQuery = params.get('search');
      const searchInput = document.getElementById('book-search-input');
      if (searchInput) searchInput.value = this.searchQuery;
    }
    if (params.has('category')) {
      this.selectedCategory = params.get('category');
    }
  },

  populateCategoryDropdown() {
    const catSelect = document.getElementById('book-category-filter');
    const formCatSelect = document.getElementById('book-form-category');
    const categories = window.StorageManager.getCategories();

    if (catSelect) {
      categories.forEach(cat => {
        const opt = document.createElement('option');
        opt.value = cat.name;
        opt.textContent = cat.name;
        if (cat.name === this.selectedCategory) opt.selected = true;
        catSelect.appendChild(opt);
      });
    }

    if (formCatSelect) {
      formCatSelect.innerHTML = categories.map(cat => 
        `<option value="${window.Utils.escapeHTML(cat.name)}">${window.Utils.escapeHTML(cat.name)}</option>`
      ).join('');
    }
  },

  bindEvents() {
    // Search input
    const searchInput = document.getElementById('book-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', window.Utils.debounce((e) => {
        this.searchQuery = e.target.value.trim().toLowerCase();
        this.currentPage = 1;
        this.render();
      }, 300));
    }

    // Category filter
    const catFilter = document.getElementById('book-category-filter');
    if (catFilter) {
      catFilter.addEventListener('change', (e) => {
        this.selectedCategory = e.target.value;
        this.currentPage = 1;
        this.render();
      });
    }

    // Availability filter
    const availFilter = document.getElementById('book-availability-filter');
    if (availFilter) {
      availFilter.addEventListener('change', (e) => {
        this.selectedAvailability = e.target.value;
        this.currentPage = 1;
        this.render();
      });
    }

    // Sort select
    const sortSelect = document.getElementById('book-sort-select');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        this.sortBy = e.target.value;
        this.render();
      });
    }

    // View toggles
    const gridBtn = document.getElementById('view-grid-btn');
    const tableBtn = document.getElementById('view-table-btn');
    if (gridBtn && tableBtn) {
      gridBtn.addEventListener('click', () => {
        this.currentView = 'grid';
        gridBtn.classList.add('active');
        tableBtn.classList.remove('active');
        this.render();
      });
      tableBtn.addEventListener('click', () => {
        this.currentView = 'table';
        tableBtn.classList.add('active');
        gridBtn.classList.remove('active');
        this.render();
      });
    }

    // Add Book Modal Triggers
    const openAddBtn = document.getElementById('open-add-book-modal-btn');
    const modalCloseBtn = document.getElementById('book-modal-close');
    const modalCancelBtn = document.getElementById('book-modal-cancel');
    const bookForm = document.getElementById('book-form');

    if (openAddBtn) {
      openAddBtn.addEventListener('click', () => this.openAddModal());
    }
    if (modalCloseBtn) {
      modalCloseBtn.addEventListener('click', () => this.closeModal());
    }
    if (modalCancelBtn) {
      modalCancelBtn.addEventListener('click', () => this.closeModal());
    }
    if (bookForm) {
      bookForm.addEventListener('submit', (e) => this.handleFormSubmit(e));
    }
  },

  getFilteredBooks() {
    let books = window.StorageManager.getBooks();

    // Text search
    if (this.searchQuery) {
      const q = this.searchQuery.toLowerCase();
      books = books.filter(b => 
        (b.title && b.title.toLowerCase().includes(q)) ||
        (b.author && b.author.toLowerCase().includes(q)) ||
        (b.isbn && b.isbn.toLowerCase().includes(q)) ||
        (b.publisher && b.publisher.toLowerCase().includes(q))
      );
    }

    // Category filter
    if (this.selectedCategory !== 'all') {
      books = books.filter(b => b.category === this.selectedCategory);
    }

    // Availability filter
    if (this.selectedAvailability === 'available') {
      books = books.filter(b => parseInt(b.availableCopies, 10) > 0);
    } else if (this.selectedAvailability === 'unavailable') {
      books = books.filter(b => parseInt(b.availableCopies, 10) === 0);
    }

    // Sorting
    books.sort((a, b) => {
      if (this.sortBy === 'title-asc') return a.title.localeCompare(b.title);
      if (this.sortBy === 'title-desc') return b.title.localeCompare(a.title);
      if (this.sortBy === 'year-desc') return (b.publicationYear || 0) - (a.publicationYear || 0);
      if (this.sortBy === 'year-asc') return (a.publicationYear || 0) - (b.publicationYear || 0);
      if (this.sortBy === 'copies-desc') return (b.availableCopies || 0) - (a.availableCopies || 0);
      return 0;
    });

    return books;
  },

  render() {
    const books = this.getFilteredBooks();
    const countEl = document.getElementById('books-result-count');
    if (countEl) {
      countEl.textContent = `Showing ${books.length} book${books.length === 1 ? '' : 's'}`;
    }

    const gridContainer = document.getElementById('books-grid-view');
    const tableContainer = document.getElementById('books-table-view');

    if (!gridContainer || !tableContainer) return;

    if (books.length === 0) {
      gridContainer.style.display = 'none';
      tableContainer.style.display = 'block';
      tableContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
          </div>
          <h3 class="empty-title">No books match your criteria</h3>
          <p class="empty-desc">Try modifying your keyword search, category filter, or reset your filters.</p>
          <button class="btn btn-secondary" onclick="BooksController.resetFilters()">Clear Filters</button>
        </div>
      `;
      this.renderPagination(0);
      return;
    }

    // Paginate
    const totalPages = Math.ceil(books.length / this.pageSize);
    if (this.currentPage > totalPages) this.currentPage = totalPages || 1;
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const pageBooks = books.slice(startIndex, startIndex + this.pageSize);

    if (this.currentView === 'grid') {
      tableContainer.style.display = 'none';
      gridContainer.style.display = 'grid';
      this.renderGridView(pageBooks, gridContainer);
    } else {
      gridContainer.style.display = 'none';
      tableContainer.style.display = 'block';
      this.renderTableView(pageBooks, tableContainer);
    }

    this.renderPagination(books.length);
    if (window.lucide) window.lucide.createIcons();
  },

  renderGridView(books, container) {
    container.innerHTML = books.map(book => {
      const isAvailable = parseInt(book.availableCopies, 10) > 0;
      const badge = isAvailable 
        ? `<span class="badge badge-success">${book.availableCopies} Available</span>`
        : `<span class="badge badge-danger">Out of Stock</span>`;

      return `
        <div class="book-card">
          <div class="book-card-cover-wrap">
            <img src="${book.coverImage}" alt="${window.Utils.escapeHTML(book.title)}" class="book-card-cover" loading="lazy" />
            <div class="book-card-badge">${badge}</div>
          </div>
          <div class="book-card-body">
            <div class="book-card-category">${window.Utils.escapeHTML(book.category)}</div>
            <a href="/book-details.html?id=${book.id}" class="book-card-title">${window.Utils.escapeHTML(book.title)}</a>
            <div class="book-card-author">${window.Utils.escapeHTML(book.author)} (${book.publicationYear})</div>
            <div style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.75rem;">
              ISBN: <span class="tabular-nums font-mono">${window.Utils.escapeHTML(book.isbn)}</span>
            </div>
            <div class="book-card-footer">
              <span class="shelf-tag">Shelf ${window.Utils.escapeHTML(book.shelfNumber)}</span>
              <div class="table-actions">
                <a href="/book-details.html?id=${book.id}" class="action-icon-btn" title="View Details">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                </a>
                <button class="action-icon-btn" onclick="BooksController.openEditModal('${book.id}')" title="Edit Book">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                </button>
                <button class="action-icon-btn delete-btn" onclick="BooksController.confirmDeleteBook('${book.id}')" title="Delete Book">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    }).join('');
  },

  renderTableView(books, container) {
    container.innerHTML = `
      <div class="card">
        <div class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Book &amp; Title</th>
                <th>ISBN</th>
                <th>Category</th>
                <th>Author</th>
                <th>Shelf</th>
                <th class="text-right">Copies</th>
                <th>Status</th>
                <th class="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              ${books.map(book => {
                const isAvail = parseInt(book.availableCopies, 10) > 0;
                return `
                  <tr>
                    <td>
                      <div class="table-book-cell">
                        <img src="${book.coverImage}" alt="${window.Utils.escapeHTML(book.title)}" class="table-book-thumb" />
                        <div>
                          <a href="/book-details.html?id=${book.id}" class="table-primary-text">${window.Utils.escapeHTML(book.title)}</a>
                          <div class="table-secondary-text">${window.Utils.escapeHTML(book.publisher)} (${book.publicationYear})</div>
                        </div>
                      </div>
                    </td>
                    <td class="tabular-nums font-mono">${window.Utils.escapeHTML(book.isbn)}</td>
                    <td>${window.Utils.escapeHTML(book.category)}</td>
                    <td>${window.Utils.escapeHTML(book.author)}</td>
                    <td><span class="shelf-tag">${window.Utils.escapeHTML(book.shelfNumber)}</span></td>
                    <td class="text-right tabular-nums"><strong>${book.availableCopies}</strong> / ${book.totalCopies}</td>
                    <td>
                      <span class="badge ${isAvail ? 'badge-success' : 'badge-danger'}">
                        ${isAvail ? 'Available' : 'Reserved'}
                      </span>
                    </td>
                    <td class="text-right">
                      <div class="table-actions">
                        <a href="/book-details.html?id=${book.id}" class="action-icon-btn" title="View Details">
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </a>
                        <button class="action-icon-btn" onclick="BooksController.openEditModal('${book.id}')" title="Edit">
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <button class="action-icon-btn delete-btn" onclick="BooksController.confirmDeleteBook('${book.id}')" title="Delete">
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  renderPagination(totalItems) {
    const container = document.getElementById('books-pagination');
    if (!container) return;

    const totalPages = Math.ceil(totalItems / this.pageSize);
    if (totalPages <= 1) {
      container.style.display = 'none';
      return;
    }
    container.style.display = 'flex';

    const start = (this.currentPage - 1) * this.pageSize + 1;
    const end = Math.min(this.currentPage * this.pageSize, totalItems);

    let html = `
      <div style="font-size: 0.8125rem; color: var(--text-muted);">
        Showing <strong class="tabular-nums">${start}</strong> to <strong class="tabular-nums">${end}</strong> of <strong class="tabular-nums">${totalItems}</strong> books
      </div>
      <div class="pagination-controls">
        <button class="btn btn-secondary btn-sm" ${this.currentPage === 1 ? 'disabled' : ''} onclick="BooksController.goToPage(${this.currentPage - 1})">
          Previous
        </button>
    `;

    for (let p = 1; p <= totalPages; p++) {
      html += `
        <button class="page-num-btn ${p === this.currentPage ? 'active' : ''}" onclick="BooksController.goToPage(${p})">
          ${p}
        </button>
      `;
    }

    html += `
        <button class="btn btn-secondary btn-sm" ${this.currentPage === totalPages ? 'disabled' : ''} onclick="BooksController.goToPage(${this.currentPage + 1})">
          Next
        </button>
      </div>
    `;

    container.innerHTML = html;
  },

  goToPage(pageNum) {
    this.currentPage = pageNum;
    this.render();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  resetFilters() {
    this.searchQuery = '';
    this.selectedCategory = 'all';
    this.selectedAvailability = 'all';
    this.sortBy = 'title-asc';
    this.currentPage = 1;

    const s = document.getElementById('book-search-input');
    const c = document.getElementById('book-category-filter');
    const a = document.getElementById('book-availability-filter');
    if (s) s.value = '';
    if (c) c.value = 'all';
    if (a) a.value = 'all';
    this.render();
  },

  openAddModal() {
    this.editingBookId = null;
    const modal = document.getElementById('book-modal');
    const title = document.getElementById('book-modal-title');
    const form = document.getElementById('book-form');
    
    if (modal && title && form) {
      title.textContent = 'Add New Book';
      form.reset();
      window.Validation.clearAllErrors(form);
      document.getElementById('book-form-cover').value = '/assets/images/book-covers/cover-1.svg';
      modal.classList.add('active');
    }
  },

  openEditModal(bookId) {
    this.editingBookId = bookId;
    const books = window.StorageManager.getBooks();
    const book = books.find(b => b.id === bookId);
    if (!book) return;

    const modal = document.getElementById('book-modal');
    const title = document.getElementById('book-modal-title');
    const form = document.getElementById('book-form');

    if (modal && title && form) {
      title.textContent = `Edit Book: ${book.title}`;
      window.Validation.clearAllErrors(form);

      document.getElementById('book-form-title').value = book.title || '';
      document.getElementById('book-form-isbn').value = book.isbn || '';
      document.getElementById('book-form-author').value = book.author || '';
      document.getElementById('book-form-category').value = book.category || '';
      document.getElementById('book-form-publisher').value = book.publisher || '';
      document.getElementById('book-form-year').value = book.publicationYear || '';
      document.getElementById('book-form-shelf').value = book.shelfNumber || '';
      document.getElementById('book-form-total').value = book.totalCopies || 1;
      document.getElementById('book-form-available').value = book.availableCopies || 0;
      document.getElementById('book-form-price').value = book.price || 0;
      document.getElementById('book-form-cover').value = book.coverImage || '/assets/images/book-covers/cover-1.svg';
      document.getElementById('book-form-desc').value = book.description || '';

      modal.classList.add('active');
    }
  },

  closeModal() {
    const modal = document.getElementById('book-modal');
    if (modal) modal.classList.remove('active');
    this.editingBookId = null;
  },

  handleFormSubmit(e) {
    e.preventDefault();
    const form = document.getElementById('book-form');
    window.Validation.clearAllErrors(form);

    const titleInput = document.getElementById('book-form-title');
    const isbnInput = document.getElementById('book-form-isbn');
    const authorInput = document.getElementById('book-form-author');
    const categoryInput = document.getElementById('book-form-category');
    const publisherInput = document.getElementById('book-form-publisher');
    const yearInput = document.getElementById('book-form-year');
    const shelfInput = document.getElementById('book-form-shelf');
    const totalInput = document.getElementById('book-form-total');
    const availInput = document.getElementById('book-form-available');
    const priceInput = document.getElementById('book-form-price');
    const coverInput = document.getElementById('book-form-cover');
    const descInput = document.getElementById('book-form-desc');

    let isValid = true;

    // Title
    if (!titleInput.value.trim()) {
      window.Validation.setFieldError(titleInput, 'Book title is required');
      isValid = false;
    }

    // ISBN
    const isbnVal = isbnInput.value.trim();
    if (!isbnVal) {
      window.Validation.setFieldError(isbnInput, 'ISBN is required');
      isValid = false;
    } else if (!window.Validation.isValidISBN(isbnVal)) {
      window.Validation.setFieldError(isbnInput, 'Invalid ISBN format (10 or 13 digits)');
      isValid = false;
    } else if (!window.Validation.isUniqueISBN(isbnVal, this.editingBookId)) {
      window.Validation.setFieldError(isbnInput, 'This ISBN is already assigned to another book');
      isValid = false;
    }

    // Author
    if (!authorInput.value.trim()) {
      window.Validation.setFieldError(authorInput, 'Author name is required');
      isValid = false;
    }

    // Copies validation
    const copiesCheck = window.Validation.validateBookCopies(totalInput.value, availInput.value);
    if (!copiesCheck.valid) {
      window.Validation.setFieldError(availInput, copiesCheck.message);
      isValid = false;
    }

    if (!isValid) return;

    const books = window.StorageManager.getBooks();

    if (this.editingBookId) {
      // Update existing book
      const index = books.findIndex(b => b.id === this.editingBookId);
      if (index !== -1) {
        books[index] = {
          ...books[index],
          title: titleInput.value.trim(),
          isbn: isbnVal,
          author: authorInput.value.trim(),
          category: categoryInput.value,
          publisher: publisherInput.value.trim(),
          publicationYear: parseInt(yearInput.value, 10) || new Date().getFullYear(),
          shelfNumber: shelfInput.value.trim() || 'General',
          totalCopies: parseInt(totalInput.value, 10),
          availableCopies: parseInt(availInput.value, 10),
          price: parseFloat(priceInput.value) || 0,
          coverImage: coverInput.value,
          description: descInput.value.trim()
        };
        window.StorageManager.saveBooks(books);
        window.Utils.showToast('Book updated successfully', 'success');
      }
    } else {
      // Create new book
      const newId = window.Utils.generateId('BK', books);
      const newBook = {
        id: newId,
        title: titleInput.value.trim(),
        isbn: isbnVal,
        author: authorInput.value.trim(),
        authorId: 'AUT-01',
        category: categoryInput.value,
        publisher: publisherInput.value.trim() || 'Academic Press',
        publicationYear: parseInt(yearInput.value, 10) || new Date().getFullYear(),
        language: 'English',
        shelfNumber: shelfInput.value.trim() || 'A-01-01',
        totalCopies: parseInt(totalInput.value, 10),
        availableCopies: parseInt(availInput.value, 10),
        price: parseFloat(priceInput.value) || 29.99,
        coverImage: coverInput.value || '/assets/images/book-covers/cover-1.svg',
        description: descInput.value.trim() || 'Standard library edition.'
      };
      books.unshift(newBook);
      window.StorageManager.saveBooks(books);
      window.Utils.showToast('New book cataloged successfully', 'success');
    }

    this.closeModal();
    this.render();
  },

  confirmDeleteBook(bookId) {
    const books = window.StorageManager.getBooks();
    const book = books.find(b => b.id === bookId);
    if (!book) return;

    // Check if there are active loans for this book
    const loans = window.StorageManager.getLoans();
    const activeLoans = loans.filter(l => l.bookId === bookId && !l.returnDate);

    if (activeLoans.length > 0) {
      window.Utils.showToast(`Cannot delete: ${activeLoans.length} active copy is currently borrowed.`, 'danger');
      return;
    }

    window.Utils.confirmDialog({
      title: 'Delete Book Record',
      message: `Are you sure you want to delete "${book.title}" (${book.isbn})? This action cannot be undone.`,
      confirmText: 'Delete Book',
      isDestructive: true,
      onConfirm: () => {
        const remaining = books.filter(b => b.id !== bookId);
        window.StorageManager.saveBooks(remaining);
        window.Utils.showToast('Book record removed from catalog', 'success');
        this.render();
      }
    });
  }
};

window.BooksController = BooksController;
