/**
 * Athenaeum System Settings Controller
 * Circulation rules, fine configuration, library institution metadata, and demo data reset
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('settings-page-container')) {
    SettingsController.init();
  }
});

const SettingsController = {
  init() {
    this.loadSettings();
    this.bindEvents();
  },

  loadSettings() {
    const settings = window.StorageManager.getSettings();

    const nameInput = document.getElementById('setting-library-name');
    const emailInput = document.getElementById('setting-library-email');
    const phoneInput = document.getElementById('setting-library-phone');
    const addressInput = document.getElementById('setting-library-address');
    const loanDaysInput = document.getElementById('setting-loan-days');
    const maxBooksInput = document.getElementById('setting-max-books');
    const fineRateInput = document.getElementById('setting-fine-rate');

    if (nameInput) nameInput.value = settings.libraryName || '';
    if (emailInput) emailInput.value = settings.libraryEmail || '';
    if (phoneInput) phoneInput.value = settings.libraryPhone || '';
    if (addressInput) addressInput.value = settings.libraryAddress || '';
    if (loanDaysInput) loanDaysInput.value = settings.loanDurationDays || 14;
    if (maxBooksInput) maxBooksInput.value = settings.maxBooksPerMember || 5;
    if (fineRateInput) fineRateInput.value = settings.dailyFineRate || 0.50;
  },

  bindEvents() {
    const rulesForm = document.getElementById('circulation-rules-form');
    const libraryForm = document.getElementById('library-info-form');
    const resetBtn = document.getElementById('settings-reset-data-btn');

    if (rulesForm) {
      rulesForm.addEventListener('submit', (e) => this.handleSaveRules(e));
    }

    if (libraryForm) {
      libraryForm.addEventListener('submit', (e) => this.handleSaveLibraryInfo(e));
    }

    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        window.Utils.confirmDialog({
          title: 'Reset All Demo Data',
          message: 'Are you sure you want to restore the entire library database to original seed data? All added books, members, issues, returns, and custom settings will be replaced.',
          confirmText: 'Reset Everything',
          isDestructive: true,
          onConfirm: () => {
            window.StorageManager.resetToDefaults();
            window.Utils.showToast('All demo data restored to initial factory state', 'success');
            setTimeout(() => window.location.reload(), 1000);
          }
        });
      });
    }
  },

  handleSaveRules(e) {
    e.preventDefault();
    const loanDaysInput = document.getElementById('setting-loan-days');
    const maxBooksInput = document.getElementById('setting-max-books');
    const fineRateInput = document.getElementById('setting-fine-rate');

    const loanDays = parseInt(loanDaysInput.value, 10);
    const maxBooks = parseInt(maxBooksInput.value, 10);
    const fineRate = parseFloat(fineRateInput.value);

    if (isNaN(loanDays) || loanDays < 1) {
      window.Utils.showToast('Loan duration must be at least 1 day', 'danger');
      return;
    }
    if (isNaN(maxBooks) || maxBooks < 1) {
      window.Utils.showToast('Max books limit must be at least 1', 'danger');
      return;
    }
    if (isNaN(fineRate) || fineRate < 0) {
      window.Utils.showToast('Fine rate cannot be negative', 'danger');
      return;
    }

    const settings = window.StorageManager.getSettings();
    settings.loanDurationDays = loanDays;
    settings.maxBooksPerMember = maxBooks;
    settings.dailyFineRate = fineRate;

    window.StorageManager.saveSettings(settings);
    window.Utils.showToast('Circulation policy rules saved successfully', 'success');
  },

  handleSaveLibraryInfo(e) {
    e.preventDefault();
    const nameInput = document.getElementById('setting-library-name');
    const emailInput = document.getElementById('setting-library-email');
    const phoneInput = document.getElementById('setting-library-phone');
    const addressInput = document.getElementById('setting-library-address');

    const name = nameInput.value.trim();
    if (!name) {
      window.Utils.showToast('Library institution name is required', 'danger');
      return;
    }

    const settings = window.StorageManager.getSettings();
    settings.libraryName = name;
    settings.libraryEmail = emailInput.value.trim();
    settings.libraryPhone = phoneInput.value.trim();
    settings.libraryAddress = addressInput.value.trim();

    window.StorageManager.saveSettings(settings);
    window.Utils.showToast('Institution details saved successfully', 'success');
  }
};

window.SettingsController = SettingsController;
