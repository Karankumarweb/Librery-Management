/**
 * Athenaeum Utility Library
 * Shared helper functions for formatting, modals, toasts, and CSV export
 */

const Utils = {
  /**
   * Generates next sequential unique ID for a collection
   */
  generateId(prefix = 'REC', collection = []) {
    if (!collection || collection.length === 0) {
      return `${prefix}-1001`;
    }
    const numbers = collection.map(item => {
      const parts = item.id.split('-');
      const num = parseInt(parts[1], 10);
      return isNaN(num) ? 0 : num;
    });
    const maxNum = Math.max(...numbers, 1000);
    return `${prefix}-${maxNum + 1}`;
  },

  /**
   * Escape HTML to prevent XSS when rendering dynamic user text
   */
  escapeHTML(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  },

  /**
   * Format date into readable standard (e.g. Oct 19, 2026)
   */
  formatDate(dateStr) {
    if (!dateStr) return '—';
    try {
      const d = new Date(dateStr + (dateStr.includes('T') ? '' : 'T00:00:00'));
      if (isNaN(d.getTime())) return dateStr;
      return d.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return dateStr;
    }
  },

  /**
   * Format ISO date time
   */
  formatDateTime(isoStr) {
    if (!isoStr) return '—';
    try {
      const d = new Date(isoStr);
      if (isNaN(d.getTime())) return isoStr;
      return d.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return isoStr;
    }
  },

  /**
   * Today formatted as YYYY-MM-DD
   */
  getTodayString() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  /**
   * Add days to a given YYYY-MM-DD date string
   */
  addDays(dateStr, days) {
    const d = new Date(dateStr + 'T00:00:00');
    d.setDate(d.getDate() + days);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  /**
   * Calculate overdue days relative to a reference date (or today)
   */
  calculateOverdueDays(dueDateStr, returnDateStr = null) {
    if (!dueDateStr) return 0;
    const due = new Date(dueDateStr + 'T00:00:00');
    const target = returnDateStr 
      ? new Date(returnDateStr + 'T00:00:00') 
      : new Date(Utils.getTodayString() + 'T00:00:00');
    
    const diffTime = target.getTime() - due.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  },

  /**
   * Currency formatting
   */
  formatCurrency(amount, currency = 'USD') {
    const num = parseFloat(amount) || 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(num);
  },

  /**
   * Show toast alert in bottom right
   */
  showToast(message, type = 'info', duration = 3500) {
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    // Icon based on type
    let iconSvg = '';
    if (type === 'success') {
      iconSvg = '<svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>';
    } else if (type === 'danger') {
      iconSvg = '<svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>';
    } else if (type === 'warning') {
      iconSvg = '<svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>';
    } else {
      iconSvg = '<svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>';
    }

    toast.innerHTML = `
      <span class="toast-icon">${iconSvg}</span>
      <span class="toast-message">${Utils.escapeHTML(message)}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(20px)';
      toast.style.transition = 'all 200ms ease';
      setTimeout(() => toast.remove(), 250);
    }, duration);
  },

  /**
   * Confirmation Modal Dialog
   */
  confirmDialog({ title = 'Confirm Action', message = 'Are you sure you want to proceed?', confirmText = 'Confirm', cancelText = 'Cancel', isDestructive = false, onConfirm }) {
    let overlay = document.getElementById('global-confirm-modal');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'global-confirm-modal';
      overlay.className = 'modal-overlay';
      document.body.appendChild(overlay);
    }

    overlay.innerHTML = `
      <div class="modal-container modal-sm">
        <div class="modal-header">
          <h3 class="modal-title">${Utils.escapeHTML(title)}</h3>
          <button class="modal-close-btn" id="confirm-modal-close" aria-label="Close dialog">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div class="modal-body">
          <p style="font-size: 0.9375rem; color: var(--text-main); line-height: 1.5;">${Utils.escapeHTML(message)}</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" id="confirm-modal-cancel">${Utils.escapeHTML(cancelText)}</button>
          <button class="btn ${isDestructive ? 'btn-danger' : 'btn-primary'}" id="confirm-modal-proceed">${Utils.escapeHTML(confirmText)}</button>
        </div>
      </div>
    `;

    overlay.classList.add('active');

    const closeModal = () => {
      overlay.classList.remove('active');
    };

    document.getElementById('confirm-modal-close').onclick = closeModal;
    document.getElementById('confirm-modal-cancel').onclick = closeModal;
    document.getElementById('confirm-modal-proceed').onclick = () => {
      closeModal();
      if (typeof onConfirm === 'function') onConfirm();
    };

    overlay.onclick = (e) => {
      if (e.target === overlay) closeModal();
    };
  },

  /**
   * Export array of objects to CSV file download
   */
  exportToCSV(filename, rows, headers) {
    if (!rows || !rows.length) {
      Utils.showToast('No records available to export', 'warning');
      return;
    }

    const keys = Object.keys(headers);
    const headerRow = keys.map(k => `"${headers[k].replace(/"/g, '""')}"`).join(',');

    const csvRows = rows.map(row => {
      return keys.map(k => {
        let val = row[k] !== undefined && row[k] !== null ? String(row[k]) : '';
        return `"${val.replace(/"/g, '""')}"`;
      }).join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headerRow, ...csvRows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}_${Utils.getTodayString()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    Utils.showToast(`Exported ${filename}.csv successfully`, 'success');
  },

  /**
   * Simple Debounce
   */
  debounce(func, wait = 250) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
};

window.Utils = Utils;
