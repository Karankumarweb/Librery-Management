/**
 * Athenaeum Reservation Management Controller
 * Reservation queueing, status transitions (Pending, Ready, Fulfilled, Cancelled)
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('reservations-page-container')) {
    ReservationsController.init();
  }
});

const ReservationsController = {
  statusFilter: 'all',

  init() {
    this.populateDropdowns();
    this.bindEvents();
    this.render();
  },

  populateDropdowns() {
    const memberSel = document.getElementById('res-form-member');
    const bookSel = document.getElementById('res-form-book');

    const members = window.StorageManager.getMembers();
    const books = window.StorageManager.getBooks();

    if (memberSel) {
      memberSel.innerHTML = '<option value="">-- Choose Member --</option>' +
        members.map(m => `<option value="${m.id}">${window.Utils.escapeHTML(m.fullName)} (${m.id})</option>`).join('');
    }

    if (bookSel) {
      bookSel.innerHTML = '<option value="">-- Choose Book --</option>' +
        books.map(b => `<option value="${b.id}">${window.Utils.escapeHTML(b.title)} (${b.availableCopies} available)</option>`).join('');
    }
  },

  bindEvents() {
    const searchInput = document.getElementById('res-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', window.Utils.debounce(() => this.render(), 250));
    }

    const filterSel = document.getElementById('res-status-filter');
    if (filterSel) {
      filterSel.addEventListener('change', (e) => {
        this.statusFilter = e.target.value;
        this.render();
      });
    }

    const openAddBtn = document.getElementById('open-add-res-btn');
    const modalClose = document.getElementById('res-modal-close');
    const modalCancel = document.getElementById('res-modal-cancel');
    const form = document.getElementById('res-form');

    if (openAddBtn) {
      openAddBtn.addEventListener('click', () => {
        document.getElementById('res-form').reset();
        document.getElementById('res-modal').classList.add('active');
      });
    }
    if (modalClose) {
      modalClose.addEventListener('click', () => document.getElementById('res-modal').classList.remove('active'));
    }
    if (modalCancel) {
      modalCancel.addEventListener('click', () => document.getElementById('res-modal').classList.remove('active'));
    }
    if (form) {
      form.addEventListener('submit', (e) => this.handleCreateReservation(e));
    }
  },

  render() {
    const tableBody = document.getElementById('reservations-table-body');
    if (!tableBody) return;

    let res = window.StorageManager.getReservations();
    const searchInput = document.getElementById('res-search-input');
    const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

    if (q) {
      res = res.filter(r => 
        (r.id && r.id.toLowerCase().includes(q)) ||
        (r.memberName && r.memberName.toLowerCase().includes(q)) ||
        (r.bookTitle && r.bookTitle.toLowerCase().includes(q)) ||
        (r.memberId && r.memberId.toLowerCase().includes(q))
      );
    }

    if (this.statusFilter !== 'all') {
      res = res.filter(r => r.status === this.statusFilter);
    }

    if (res.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="6" style="text-align: center; padding: 2.5rem; color: var(--text-muted);">
            No reservations match your filters.
          </td>
        </tr>
      `;
      return;
    }

    tableBody.innerHTML = res.map(r => {
      let badgeClass = 'badge-warning';
      if (r.status === 'Ready') badgeClass = 'badge-success';
      if (r.status === 'Fulfilled') badgeClass = 'badge-info';
      if (r.status === 'Cancelled') badgeClass = 'badge-neutral';

      return `
        <tr>
          <td class="font-mono tabular-nums" style="font-weight: 600;">${r.id}</td>
          <td>
            <div style="font-weight: 700; color: var(--text-main);">${window.Utils.escapeHTML(r.bookTitle)}</div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">${r.bookId}</div>
          </td>
          <td>
            <div>${window.Utils.escapeHTML(r.memberName)}</div>
            <div style="font-size: 0.75rem; color: var(--text-muted);">${r.memberId}</div>
          </td>
          <td class="tabular-nums">${window.Utils.formatDate(r.reservationDate)}</td>
          <td class="tabular-nums" style="text-align: center;">
            <span class="badge badge-neutral">#${r.queuePosition} in Queue</span>
          </td>
          <td>
            <span class="badge ${badgeClass}">${r.status}</span>
          </td>
          <td class="text-right">
            <div class="table-actions">
              ${r.status === 'Ready' ? `
                <a href="/issue-book.html?bookId=${r.bookId}&memberId=${r.memberId}" class="btn btn-primary btn-sm" title="Fulfill with Issue">
                  Issue Now
                </a>
              ` : ''}
              ${r.status === 'Pending' || r.status === 'Ready' ? `
                <button class="btn btn-secondary btn-sm" onclick="ReservationsController.markFulfilled('${r.id}')" title="Mark Fulfilled">
                  Fulfill
                </button>
                <button class="action-icon-btn delete-btn" onclick="ReservationsController.cancelReservation('${r.id}')" title="Cancel Reservation">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                </button>
              ` : ''}
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  handleCreateReservation(e) {
    e.preventDefault();
    const memberId = document.getElementById('res-form-member').value;
    const bookId = document.getElementById('res-form-book').value;

    if (!memberId || !bookId) {
      window.Utils.showToast('Please select both a member and a book.', 'warning');
      return;
    }

    const reservations = window.StorageManager.getReservations();
    const members = window.StorageManager.getMembers();
    const books = window.StorageManager.getBooks();

    const member = members.find(m => m.id === memberId);
    const book = books.find(b => b.id === bookId);

    // Business Rule 9: Prevent duplicate active reservations by the same member for the same book
    const duplicate = reservations.some(r => 
      r.memberId === memberId && 
      r.bookId === bookId && 
      (r.status === 'Pending' || r.status === 'Ready')
    );

    if (duplicate) {
      window.Utils.showToast(`${member.fullName} already has an active reservation for "${book.title}".`, 'danger');
      return;
    }

    // Determine queue position
    const activeForBook = reservations.filter(r => r.bookId === bookId && r.status === 'Pending');
    const queuePos = activeForBook.length + 1;

    // Check if copies are currently available; if so, can immediately be set to 'Ready'
    const isAvail = parseInt(book.availableCopies, 10) > 0;
    const status = isAvail ? 'Ready' : 'Pending';

    const newRes = {
      id: window.Utils.generateId('RES', reservations),
      bookId: book.id,
      bookTitle: book.title,
      memberId: member.id,
      memberName: member.fullName,
      reservationDate: window.Utils.getTodayString(),
      queuePosition: queuePos,
      status: status,
      notificationSent: isAvail
    };

    reservations.unshift(newRes);
    window.StorageManager.saveReservations(reservations);

    // Notification
    const notifs = window.StorageManager.getNotifications();
    notifs.unshift({
      id: window.Utils.generateId('NOTIF', notifs),
      title: 'New Reservation Placed',
      message: `Reservation #${newRes.id} for "${book.title}" placed by ${member.fullName} (${status}).`,
      type: 'info',
      timestamp: new Date().toISOString(),
      read: false,
      link: '/reservations.html'
    });
    window.StorageManager.saveNotifications(notifs);

    document.getElementById('res-modal').classList.remove('active');
    window.Utils.showToast(`Reservation registered (Status: ${status})`, 'success');
    this.render();
  },

  markFulfilled(resId) {
    const reservations = window.StorageManager.getReservations();
    const idx = reservations.findIndex(r => r.id === resId);
    if (idx !== -1) {
      reservations[idx].status = 'Fulfilled';
      window.StorageManager.saveReservations(reservations);
      window.Utils.showToast('Reservation marked as fulfilled.', 'success');
      this.render();
    }
  },

  cancelReservation(resId) {
    window.Utils.confirmDialog({
      title: 'Cancel Reservation',
      message: 'Are you sure you want to cancel this reservation?',
      confirmText: 'Cancel Reservation',
      isDestructive: true,
      onConfirm: () => {
        const reservations = window.StorageManager.getReservations();
        const idx = reservations.findIndex(r => r.id === resId);
        if (idx !== -1) {
          reservations[idx].status = 'Cancelled';
          window.StorageManager.saveReservations(reservations);
          window.Utils.showToast('Reservation cancelled', 'info');
          this.render();
        }
      }
    });
  }
};

window.ReservationsController = ReservationsController;
