/**
 * Athenaeum Circulation: Issue Book Controller
 * Validation of borrowing limits, member status, stock decrements, and receipts
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('issue-book-page-container')) {
    IssueBookController.init();
  }
});

const IssueBookController = {
  selectedMember: null,
  selectedBook: null,

  init() {
    this.populateDropdowns();
    this.initDefaultDates();
    this.bindEvents();
    this.checkUrlPreselect();
  },

  populateDropdowns() {
    const memberSelect = document.getElementById('issue-member-select');
    const bookSelect = document.getElementById('issue-book-select');

    const members = window.StorageManager.getMembers();
    const books = window.StorageManager.getBooks();

    if (memberSelect) {
      memberSelect.innerHTML = '<option value="">-- Select or Search Member --</option>' +
        members.map(m => `
          <option value="${m.id}" data-status="${m.status}">
            ${window.Utils.escapeHTML(m.fullName)} (${m.id}) - ${m.membershipType} [${m.status}]
          </option>
        `).join('');
    }

    if (bookSelect) {
      bookSelect.innerHTML = '<option value="">-- Select or Search Book --</option>' +
        books.map(b => `
          <option value="${b.id}" data-available="${b.availableCopies}">
            ${window.Utils.escapeHTML(b.title)} (${b.isbn}) - ${b.availableCopies} available
          </option>
        `).join('');
    }
  },

  initDefaultDates() {
    const today = window.Utils.getTodayString();
    const settings = window.StorageManager.getSettings();
    const loanDays = settings.loanDurationDays || 14;
    const due = window.Utils.addDays(today, loanDays);

    const issueDateInput = document.getElementById('issue-date-input');
    const dueDateInput = document.getElementById('due-date-input');

    if (issueDateInput) issueDateInput.value = today;
    if (dueDateInput) dueDateInput.value = due;
  },

  checkUrlPreselect() {
    const params = new URLSearchParams(window.location.search);
    const bookId = params.get('bookId');
    const memberId = params.get('memberId');

    if (bookId) {
      const bookSelect = document.getElementById('issue-book-select');
      if (bookSelect) {
        bookSelect.value = bookId;
        this.onBookSelected(bookId);
      }
    }

    if (memberId) {
      const memberSelect = document.getElementById('issue-member-select');
      if (memberSelect) {
        memberSelect.value = memberId;
        this.onMemberSelected(memberId);
      }
    }
  },

  bindEvents() {
    const memberSelect = document.getElementById('issue-member-select');
    const bookSelect = document.getElementById('issue-book-select');
    const issueForm = document.getElementById('issue-book-form');

    if (memberSelect) {
      memberSelect.addEventListener('change', (e) => this.onMemberSelected(e.target.value));
    }

    if (bookSelect) {
      bookSelect.addEventListener('change', (e) => this.onBookSelected(e.target.value));
    }

    if (issueForm) {
      issueForm.addEventListener('submit', (e) => this.handleIssueSubmit(e));
    }

    // Receipt modal close
    const receiptClose = document.getElementById('receipt-modal-close');
    const receiptPrint = document.getElementById('receipt-modal-print');
    if (receiptClose) {
      receiptClose.addEventListener('click', () => {
        document.getElementById('receipt-modal').classList.remove('active');
        window.location.href = '/dashboard.html';
      });
    }
    if (receiptPrint) {
      receiptPrint.addEventListener('click', () => window.print());
    }
  },

  onMemberSelected(memberId) {
    const card = document.getElementById('selected-member-card');
    if (!card) return;

    if (!memberId) {
      card.style.display = 'none';
      this.selectedMember = null;
      return;
    }

    const members = window.StorageManager.getMembers();
    const loans = window.StorageManager.getLoans();
    const member = members.find(m => m.id === memberId);
    if (!member) return;

    this.selectedMember = member;

    // Check active loans count
    const activeLoans = loans.filter(l => l.memberId === member.id && !l.returnDate);
    const maxLimit = member.maxLimit || (member.membershipType === 'Faculty' ? 10 : 5);
    const remainingSlots = Math.max(0, maxLimit - activeLoans.length);

    card.style.display = 'block';
    card.innerHTML = `
      <div style="display: flex; align-items: center; gap: 1rem;">
        <img src="${member.profileImage}" alt="${window.Utils.escapeHTML(member.fullName)}" class="table-user-thumb" style="width: 48px; height: 48px;" />
        <div style="flex: 1;">
          <div style="font-weight: 700; font-size: 1rem; color: var(--text-main);">${window.Utils.escapeHTML(member.fullName)}</div>
          <div style="font-size: 0.8125rem; color: var(--text-muted);">${window.Utils.escapeHTML(member.email)} · ${window.Utils.escapeHTML(member.membershipType)}</div>
          <div style="margin-top: 0.375rem; display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
            <span class="badge ${member.status === 'Active' ? 'badge-success' : 'badge-danger'}">${member.status}</span>
            <span class="badge ${remainingSlots > 0 ? 'badge-info' : 'badge-danger'} tabular-nums">
              ${activeLoans.length} / ${maxLimit} Borrowed (${remainingSlots} slots remaining)
            </span>
          </div>
        </div>
      </div>
    `;

    // Warn if member cannot borrow
    if (member.status !== 'Active') {
      window.Utils.showToast(`Warning: Member status is ${member.status}. Cannot issue books.`, 'danger');
    } else if (remainingSlots === 0) {
      window.Utils.showToast(`Warning: Member has reached their borrowing limit of ${maxLimit} books.`, 'warning');
    }
  },

  onBookSelected(bookId) {
    const card = document.getElementById('selected-book-card');
    if (!card) return;

    if (!bookId) {
      card.style.display = 'none';
      this.selectedBook = null;
      return;
    }

    const books = window.StorageManager.getBooks();
    const book = books.find(b => b.id === bookId);
    if (!book) return;

    this.selectedBook = book;
    const isAvail = parseInt(book.availableCopies, 10) > 0;

    card.style.display = 'block';
    card.innerHTML = `
      <div style="display: flex; align-items: center; gap: 1rem;">
        <img src="${book.coverImage}" alt="${window.Utils.escapeHTML(book.title)}" class="table-book-thumb" style="width: 44px; height: 60px;" />
        <div style="flex: 1;">
          <div style="font-weight: 700; font-size: 1rem; color: var(--text-main);">${window.Utils.escapeHTML(book.title)}</div>
          <div style="font-size: 0.8125rem; color: var(--text-muted);">${window.Utils.escapeHTML(book.author)} · Shelf: ${window.Utils.escapeHTML(book.shelfNumber)}</div>
          <div style="margin-top: 0.375rem; display: flex; align-items: center; gap: 0.5rem;">
            <span class="badge ${isAvail ? 'badge-success' : 'badge-danger'} tabular-nums">
              ${book.availableCopies} / ${book.totalCopies} Available
            </span>
            <span class="badge badge-neutral font-mono">${window.Utils.escapeHTML(book.isbn)}</span>
          </div>
        </div>
      </div>
    `;

    if (!isAvail) {
      window.Utils.showToast(`Book "${book.title}" is currently out of stock. Consider placing a reservation.`, 'danger');
    }
  },

  handleIssueSubmit(e) {
    e.preventDefault();

    if (!this.selectedMember) {
      window.Utils.showToast('Please select a borrower member.', 'danger');
      return;
    }

    if (!this.selectedBook) {
      window.Utils.showToast('Please select a book to issue.', 'danger');
      return;
    }

    // Business Rule 1: Member must be Active
    if (this.selectedMember.status !== 'Active') {
      window.Utils.showToast(`Cannot issue: Member account is ${this.selectedMember.status}.`, 'danger');
      return;
    }

    // Business Rule 2: Member borrowing limit
    const loans = window.StorageManager.getLoans();
    const activeMemberLoans = loans.filter(l => l.memberId === this.selectedMember.id && !l.returnDate);
    const maxLimit = this.selectedMember.maxLimit || (this.selectedMember.membershipType === 'Faculty' ? 10 : 5);
    if (activeMemberLoans.length >= maxLimit) {
      window.Utils.showToast(`Cannot issue: Member has reached borrowing limit of ${maxLimit} books.`, 'danger');
      return;
    }

    // Business Rule 3: Book copies must be > 0
    const books = window.StorageManager.getBooks();
    const bookIndex = books.findIndex(b => b.id === this.selectedBook.id);
    if (bookIndex === -1 || parseInt(books[bookIndex].availableCopies, 10) <= 0) {
      window.Utils.showToast('Cannot issue: No copies currently available for this book.', 'danger');
      return;
    }

    const issueDate = document.getElementById('issue-date-input').value;
    const dueDate = document.getElementById('due-date-input').value;

    // Create unique Transaction Record
    const txId = window.Utils.generateId('TX', loans);
    const newLoan = {
      id: txId,
      bookId: this.selectedBook.id,
      bookTitle: this.selectedBook.title,
      isbn: this.selectedBook.isbn,
      memberId: this.selectedMember.id,
      memberName: this.selectedMember.fullName,
      issueDate: issueDate,
      dueDate: dueDate,
      returnDate: null,
      status: 'Issued',
      overdueDays: 0,
      fineAmount: 0.00
    };

    // Business Rule 4: Decrease available copies automatically
    books[bookIndex].availableCopies = Math.max(0, parseInt(books[bookIndex].availableCopies, 10) - 1);
    window.StorageManager.saveBooks(books);

    loans.unshift(newLoan);
    window.StorageManager.saveLoans(loans);

    // Create notification
    const notifs = window.StorageManager.getNotifications();
    notifs.unshift({
      id: window.Utils.generateId('NOTIF', notifs),
      title: 'Book Issued Successfully',
      message: `"${this.selectedBook.title}" issued to ${this.selectedMember.fullName} (Due: ${dueDate}).`,
      type: 'info',
      timestamp: new Date().toISOString(),
      read: false,
      link: '/books.html'
    });
    window.StorageManager.saveNotifications(notifs);

    // Show Printable Receipt Modal
    this.showReceiptModal(newLoan, books[bookIndex].availableCopies);
  },

  showReceiptModal(loan, remainingCopies) {
    const modal = document.getElementById('receipt-modal');
    const content = document.getElementById('receipt-modal-content');
    if (!modal || !content) return;

    content.innerHTML = `
      <div style="text-align: center; margin-bottom: 1.5rem; border-bottom: 1px dashed var(--border-strong); padding-bottom: 1rem;">
        <h4 style="font-size: 1.125rem; font-weight: 700; color: var(--text-main);">ATHENAEUM UNIVERSITY LIBRARY</h4>
        <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.25rem;">Official Circulation Loan Receipt</div>
        <div style="font-size: 0.8125rem; font-family: var(--font-mono); font-weight: 700; color: var(--accent-500); margin-top: 0.5rem;">
          Transaction: ${loan.id}
        </div>
      </div>

      <div style="display: flex; flex-direction: column; gap: 0.625rem; font-size: 0.875rem;">
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Borrower:</span>
          <strong>${window.Utils.escapeHTML(loan.memberName)} (${loan.memberId})</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Book Title:</span>
          <strong style="text-align: right; max-width: 250px;">${window.Utils.escapeHTML(loan.bookTitle)}</strong>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">ISBN:</span>
          <span class="font-mono">${loan.isbn}</span>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span style="color: var(--text-muted);">Date of Issue:</span>
          <strong>${window.Utils.formatDate(loan.issueDate)}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; color: var(--danger); font-weight: 700;">
          <span>Due Date for Return:</span>
          <span>${window.Utils.formatDate(loan.dueDate)}</span>
        </div>
      </div>

      <div style="margin-top: 1.5rem; padding: 0.75rem; background-color: var(--bg-subtle); border-radius: var(--radius-md); font-size: 0.75rem; color: var(--text-muted); text-align: center;">
        Please return on or before due date to avoid overdue charges of $0.50 per day.
      </div>
    `;

    modal.classList.add('active');
  }
};

window.IssueBookController = IssueBookController;
