/**
 * Athenaeum Input Validation Library
 * Form validators, ISBN uniqueness checks, and field feedback
 */

const Validation = {
  /**
   * Validate Email format
   */
  isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).trim());
  },

  /**
   * Validate Phone format (supports international & US formats)
   */
  isValidPhone(phone) {
    const re = /^[+]?[(]?[0-9]{1,4}[)]?[-\s./0-9]{6,15}$/;
    return re.test(String(phone).trim());
  },

  /**
   * Validate ISBN format (ISBN-10 or ISBN-13, with or without hyphens)
   */
  isValidISBN(isbn) {
    if (!isbn) return false;
    const clean = isbn.replace(/[-\s]/g, '');
    return clean.length === 10 || clean.length === 13;
  },

  /**
   * Check ISBN Uniqueness in the book collection
   */
  isUniqueISBN(isbn, excludeBookId = null) {
    const books = window.StorageManager ? window.StorageManager.getBooks() : [];
    const cleanNew = isbn.replace(/[-\s]/g, '').toLowerCase();
    
    return !books.some(b => {
      if (excludeBookId && b.id === excludeBookId) return false;
      const cleanExisting = (b.isbn || '').replace(/[-\s]/g, '').toLowerCase();
      return cleanExisting === cleanNew;
    });
  },

  /**
   * Validate book copies: available must not exceed total, both >= 0
   */
  validateBookCopies(totalCopies, availableCopies) {
    const total = parseInt(totalCopies, 10);
    const available = parseInt(availableCopies, 10);

    if (isNaN(total) || total < 1) {
      return { valid: false, message: 'Total copies must be at least 1' };
    }
    if (isNaN(available) || available < 0) {
      return { valid: false, message: 'Available copies cannot be negative' };
    }
    if (available > total) {
      return { valid: false, message: 'Available copies cannot exceed total copies' };
    }

    return { valid: true };
  },

  /**
   * Set field visual error state
   */
  setFieldError(inputElement, errorMessage) {
    if (!inputElement) return;
    const group = inputElement.closest('.form-group') || inputElement.parentElement;
    group.classList.add('has-error');
    
    let errorElem = group.querySelector('.form-error');
    if (!errorElem) {
      errorElem = document.createElement('span');
      errorElem.className = 'form-error';
      group.appendChild(errorElem);
    }
    errorElem.textContent = errorMessage;
    errorElem.style.display = 'block';
  },

  /**
   * Clear field error state
   */
  clearFieldError(inputElement) {
    if (!inputElement) return;
    const group = inputElement.closest('.form-group') || inputElement.parentElement;
    group.classList.remove('has-error');
    const errorElem = group.querySelector('.form-error');
    if (errorElem) {
      errorElem.style.display = 'none';
      errorElem.textContent = '';
    }
  },

  /**
   * Clear all errors within a container
   */
  clearAllErrors(formContainer) {
    if (!formContainer) return;
    const errorGroups = formContainer.querySelectorAll('.has-error');
    errorGroups.forEach(g => {
      g.classList.remove('has-error');
      const err = g.querySelector('.form-error');
      if (err) {
        err.style.display = 'none';
        err.textContent = '';
      }
    });
  }
};

window.Validation = Validation;
