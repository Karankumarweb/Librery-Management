/**
 * Authentication & Simulated Role-Based Access Control
 * Athenaeum Library Management System
 */

const DEMO_CREDENTIALS = {
  admin: {
    email: 'admin@athenaeum.edu',
    password: 'admin123',
    role: 'Administrator',
    name: 'Eleanor Vance',
    avatar: '/assets/images/avatars/avatar-1.svg',
    memberId: 'MEM-1001'
  },
  librarian: {
    email: 'librarian@athenaeum.edu',
    password: 'lib123',
    role: 'Librarian',
    name: 'Marcus Chen',
    avatar: '/assets/images/avatars/avatar-2.svg',
    memberId: 'MEM-1002'
  },
  member: {
    email: 'member@student.athenaeum.edu',
    password: 'member123',
    role: 'Member',
    name: 'Sarah Jenkins',
    avatar: '/assets/images/avatars/avatar-3.svg',
    memberId: 'MEM-1003'
  }
};

const Auth = {
  /**
   * Get currently logged-in user
   */
  getCurrentUser() {
    return window.StorageManager.getCurrentUser();
  },

  /**
   * Check if user is logged in
   */
  isAuthenticated() {
    const user = this.getCurrentUser();
    return !!(user && user.email);
  },

  /**
   * Log in user
   */
  login(email, password, role = 'Administrator') {
    // Check against demo accounts or accept simulated matching
    let matchedProfile = null;
    const cleanEmail = (email || '').trim().toLowerCase();

    if (cleanEmail === DEMO_CREDENTIALS.admin.email.toLowerCase()) {
      matchedProfile = DEMO_CREDENTIALS.admin;
    } else if (cleanEmail === DEMO_CREDENTIALS.librarian.email.toLowerCase()) {
      matchedProfile = DEMO_CREDENTIALS.librarian;
    } else if (cleanEmail === DEMO_CREDENTIALS.member.email.toLowerCase()) {
      matchedProfile = DEMO_CREDENTIALS.member;
    } else {
      // Find among members collection if member email
      const members = window.StorageManager.getMembers();
      const existingMember = members.find(m => m.email.toLowerCase() === cleanEmail);
      if (existingMember) {
        matchedProfile = {
          email: existingMember.email,
          role: role || (existingMember.membershipType === 'Faculty' ? 'Librarian' : 'Member'),
          name: existingMember.fullName,
          avatar: existingMember.profileImage,
          memberId: existingMember.id
        };
      } else {
        // Fallback default mock user
        matchedProfile = {
          email: cleanEmail,
          role: role,
          name: cleanEmail.split('@')[0].replace('.', ' ').replace(/\b\w/g, l => l.toUpperCase()),
          avatar: '/assets/images/avatars/avatar-1.svg',
          memberId: 'MEM-1001'
        };
      }
    }

    window.StorageManager.setCurrentUser(matchedProfile);
    return { success: true, user: matchedProfile };
  },

  /**
   * Register a new member account
   */
  register(userData) {
    const members = window.StorageManager.getMembers();
    
    // Check email uniqueness
    const exists = members.some(m => m.email.toLowerCase() === userData.email.toLowerCase());
    if (exists) {
      return { success: false, message: 'A member with this email already exists.' };
    }

    const newId = window.Utils.generateId('MEM', members);
    const newMember = {
      id: newId,
      fullName: userData.fullName,
      email: userData.email,
      phone: userData.phone || '+1 (555) 000-0000',
      address: userData.address || 'Campus Residence',
      membershipType: userData.membershipType || 'Student',
      registrationDate: window.Utils.getTodayString(),
      expiryDate: window.Utils.addDays(window.Utils.getTodayString(), 365 * 3),
      status: 'Active',
      profileImage: '/assets/images/avatars/avatar-3.svg',
      maxLimit: userData.membershipType === 'Faculty' ? 10 : 5
    };

    members.push(newMember);
    window.StorageManager.saveMembers(members);

    // Auto login as new member
    const userSession = {
      email: newMember.email,
      role: 'Member',
      name: newMember.fullName,
      avatar: newMember.profileImage,
      memberId: newMember.id
    };
    window.StorageManager.setCurrentUser(userSession);

    return { success: true, member: newMember };
  },

  /**
   * Logout user and redirect to login
   */
  logout() {
    window.StorageManager.setCurrentUser(null);
    window.location.href = '/login.html';
  },

  /**
   * Protect private pages. Redirects to login if not authenticated.
   */
  requireAuth() {
    if (!this.isAuthenticated()) {
      const currentPath = encodeURIComponent(window.location.pathname + window.location.search);
      window.location.href = `/login.html?redirect=${currentPath}`;
      return false;
    }
    return true;
  },

  /**
   * Restrict access by roles (e.g., Administrator only)
   */
  requireRole(allowedRoles = []) {
    if (!this.requireAuth()) return false;
    const user = this.getCurrentUser();
    if (!allowedRoles.includes(user.role)) {
      window.Utils.showToast(`Access restricted. Requires: ${allowedRoles.join(' or ')}`, 'danger');
      setTimeout(() => {
        window.location.href = '/dashboard.html';
      }, 1500);
      return false;
    }
    return true;
  }
};

window.Auth = Auth;
window.DEMO_CREDENTIALS = DEMO_CREDENTIALS;
