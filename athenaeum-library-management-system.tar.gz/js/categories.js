/**
 * Athenaeum Category Management Controller
 * Category CRUD, book count validation, and delete prevention
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('categories-page-container')) {
    CategoriesController.init();
  }
});

const CategoriesController = {
  editingId: null,

  init() {
    this.bindEvents();
    this.render();
  },

  bindEvents() {
    const searchInput = document.getElementById('category-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', window.Utils.debounce(() => this.render(), 250));
    }

    const openAddBtn = document.getElementById('open-add-category-btn');
    const modalCloseBtn = document.getElementById('category-modal-close');
    const modalCancelBtn = document.getElementById('category-modal-cancel');
    const form = document.getElementById('category-form');

    if (openAddBtn) {
      openAddBtn.addEventListener('click', () => this.openAddModal());
    }
    if (modalCloseBtn) {
      modalCloseBtn.addEventListener('click', () => this.closeModal());
    }
    if (modalCancelBtn) {
      modalCancelBtn.addEventListener('click', () => this.closeModal());
    }
    if (form) {
      form.addEventListener('submit', (e) => this.handleFormSubmit(e));
    }
  },

  render() {
    const tableBody = document.getElementById('categories-table-body');
    if (!tableBody) return;

    let categories = window.StorageManager.getCategories();
    const books = window.StorageManager.getBooks();
    const searchInput = document.getElementById('category-search-input');
    const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

    if (q) {
      categories = categories.filter(c => 
        c.name.toLowerCase().includes(q) || 
        (c.description && c.description.toLowerCase().includes(q))
      );
    }

    if (categories.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; padding: 2.5rem; color: var(--text-muted);">
            No categories found matching your query.
          </td>
        </tr>
      `;
      return;
    }

    tableBody.innerHTML = categories.map(cat => {
      // Dynamic book count from live books collection
      const bookCount = books.filter(b => b.category === cat.name || b.categoryId === cat.id).length;

      return `
        <tr>
          <td class="tabular-nums font-mono" style="font-weight: 600;">${window.Utils.escapeHTML(cat.id)}</td>
          <td>
            <div style="font-weight: 700; color: var(--text-main); font-size: 0.9375rem;">${window.Utils.escapeHTML(cat.name)}</div>
          </td>
          <td style="color: var(--text-muted); max-width: 380px;">${window.Utils.escapeHTML(cat.description || 'General collection category')}</td>
          <td>
            <span class="badge ${bookCount > 0 ? 'badge-info' : 'badge-neutral'} tabular-nums">
              ${bookCount} book${bookCount === 1 ? '' : 's'}
            </span>
          </td>
          <td class="text-right">
            <div class="table-actions">
              <a href="/books.html?category=${encodeURIComponent(cat.name)}" class="action-icon-btn" title="View Books in Category">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
              </a>
              <button class="action-icon-btn" onclick="CategoriesController.openEditModal('${cat.id}')" title="Edit Category">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
              <button class="action-icon-btn delete-btn" onclick="CategoriesController.confirmDelete('${cat.id}')" title="Delete Category">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  },

  openAddModal() {
    this.editingId = null;
    const modal = document.getElementById('category-modal');
    const title = document.getElementById('category-modal-title');
    const form = document.getElementById('category-form');

    if (modal && title && form) {
      title.textContent = 'Add Category';
      form.reset();
      window.Validation.clearAllErrors(form);
      modal.classList.add('active');
    }
  },

  openEditModal(catId) {
    this.editingId = catId;
    const categories = window.StorageManager.getCategories();
    const cat = categories.find(c => c.id === catId);
    if (!cat) return;

    const modal = document.getElementById('category-modal');
    const title = document.getElementById('category-modal-title');
    const form = document.getElementById('category-form');

    if (modal && title && form) {
      title.textContent = `Edit Category: ${cat.name}`;
      window.Validation.clearAllErrors(form);
      document.getElementById('category-form-name').value = cat.name || '';
      document.getElementById('category-form-desc').value = cat.description || '';
      modal.classList.add('active');
    }
  },

  closeModal() {
    const modal = document.getElementById('category-modal');
    if (modal) modal.classList.remove('active');
    this.editingId = null;
  },

  handleFormSubmit(e) {
    e.preventDefault();
    const nameInput = document.getElementById('category-form-name');
    const descInput = document.getElementById('category-form-desc');
    const name = nameInput.value.trim();

    if (!name) {
      window.Validation.setFieldError(nameInput, 'Category name is required');
      return;
    }

    const categories = window.StorageManager.getCategories();

    // Check duplicate name
    const duplicate = categories.some(c => 
      c.id !== this.editingId && c.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      window.Validation.setFieldError(nameInput, 'A category with this name already exists');
      return;
    }

    if (this.editingId) {
      const idx = categories.findIndex(c => c.id === this.editingId);
      if (idx !== -1) {
        const oldName = categories[idx].name;
        categories[idx].name = name;
        categories[idx].description = descInput.value.trim();

        // Also update books assigned to this category
        const books = window.StorageManager.getBooks();
        books.forEach(b => {
          if (b.category === oldName) b.category = name;
        });
        window.StorageManager.saveBooks(books);
        window.StorageManager.saveCategories(categories);
        window.Utils.showToast('Category updated successfully', 'success');
      }
    } else {
      const newId = window.Utils.generateId('CAT', categories);
      categories.push({
        id: newId,
        name: name,
        description: descInput.value.trim(),
        count: 0
      });
      window.StorageManager.saveCategories(categories);
      window.Utils.showToast('Category created successfully', 'success');
    }

    this.closeModal();
    this.render();
  },

  confirmDelete(catId) {
    const categories = window.StorageManager.getCategories();
    const cat = categories.find(c => c.id === catId);
    if (!cat) return;

    const books = window.StorageManager.getBooks();
    const booksWithCat = books.filter(b => b.category === cat.name || b.categoryId === catId);

    // Enforce business rule: Prevent deletion if category has books
    if (booksWithCat.length > 0) {
      window.Utils.showToast(
        `Cannot delete "${cat.name}": contains ${booksWithCat.length} book(s). Reassign them first.`, 
        'danger'
      );
      return;
    }

    window.Utils.confirmDialog({
      title: 'Delete Category',
      message: `Are you sure you want to delete category "${cat.name}"?`,
      confirmText: 'Delete Category',
      isDestructive: true,
      onConfirm: () => {
        const remaining = categories.filter(c => c.id !== catId);
        window.StorageManager.saveCategories(remaining);
        window.Utils.showToast('Category deleted', 'success');
        this.render();
      }
    });
  }
};

window.CategoriesController = CategoriesController;
