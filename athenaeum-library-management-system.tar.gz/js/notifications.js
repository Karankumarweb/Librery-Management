/**
 * Athenaeum Notification Center Controller
 * System alerts, overdue notices, read/unread toggling, and clearing
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('notifications-page-container')) {
    NotificationsController.init();
  }
});

const NotificationsController = {
  filter: 'all', // 'all' | 'unread' | 'read'

  init() {
    this.bindEvents();
    this.render();
  },

  bindEvents() {
    const filterTabs = document.querySelectorAll('.notif-filter-btn');
    filterTabs.forEach(btn => {
      btn.addEventListener('click', () => {
        filterTabs.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.filter = btn.getAttribute('data-filter');
        this.render();
      });
    });

    const markAllReadBtn = document.getElementById('mark-all-read-btn');
    if (markAllReadBtn) {
      markAllReadBtn.addEventListener('click', () => this.markAllAsRead());
    }

    const clearAllBtn = document.getElementById('clear-all-notifs-btn');
    if (clearAllBtn) {
      clearAllBtn.addEventListener('click', () => this.clearAll());
    }
  },

  render() {
    const listContainer = document.getElementById('notifications-list');
    if (!listContainer) return;

    let notifs = window.StorageManager.getNotifications();

    if (this.filter === 'unread') {
      notifs = notifs.filter(n => !n.read);
    } else if (this.filter === 'read') {
      notifs = notifs.filter(n => n.read);
    }

    const countBadge = document.getElementById('notifs-count-indicator');
    if (countBadge) {
      const unreadTotal = window.StorageManager.getNotifications().filter(n => !n.read).length;
      countBadge.textContent = `${unreadTotal} unread`;
    }

    if (notifs.length === 0) {
      listContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          </div>
          <h4 style="font-size: 1.125rem; font-weight: 700; color: var(--text-main);">No Notifications</h4>
          <p class="empty-desc">You are all caught up! System alerts and overdue reminders will appear here.</p>
        </div>
      `;
      return;
    }

    listContainer.innerHTML = notifs.map(n => {
      let iconColor = 'var(--accent-500)';
      let iconBg = 'var(--accent-50)';
      if (n.type === 'danger') {
        iconColor = 'var(--danger)';
        iconBg = 'var(--danger-bg)';
      } else if (n.type === 'success') {
        iconColor = 'var(--success)';
        iconBg = 'var(--success-bg)';
      } else if (n.type === 'warning') {
        iconColor = 'var(--warning)';
        iconBg = 'var(--warning-bg)';
      }

      return `
        <div class="card" style="margin-bottom: 0.875rem; border-left: 4px solid ${iconColor}; opacity: ${n.read ? '0.75' : '1'};">
          <div class="card-body" style="padding: 1.125rem 1.25rem; display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem;">
            <div style="display: flex; align-items: flex-start; gap: 1rem; flex: 1;">
              <div style="width: 38px; height: 38px; border-radius: var(--radius-md); background: ${iconBg}; color: ${iconColor}; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
              </div>
              <div style="flex: 1;">
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                  <h4 style="font-size: 0.9375rem; font-weight: 700; color: var(--text-main);">${window.Utils.escapeHTML(n.title)}</h4>
                  ${!n.read ? '<span class="badge badge-info" style="font-size: 0.6875rem;">New</span>' : ''}
                </div>
                <p style="font-size: 0.875rem; color: var(--text-main); margin-top: 0.25rem; line-height: 1.4;">
                  ${window.Utils.escapeHTML(n.message)}
                </p>
                <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.5rem;">
                  ${window.Utils.formatDateTime(n.timestamp)}
                </div>
              </div>
            </div>

            <div style="display: flex; align-items: center; gap: 0.5rem; flex-shrink: 0;">
              ${n.link ? `
                <a href="${n.link}" class="btn btn-secondary btn-sm">View</a>
              ` : ''}
              <button class="action-icon-btn" onclick="NotificationsController.toggleRead('${n.id}')" title="${n.read ? 'Mark unread' : 'Mark as read'}">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg>
              </button>
              <button class="action-icon-btn delete-btn" onclick="NotificationsController.deleteNotification('${n.id}')" title="Delete notification">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    if (window.Navigation) window.Navigation.updateNotificationBadge();
  },

  toggleRead(id) {
    const notifs = window.StorageManager.getNotifications();
    const item = notifs.find(n => n.id === id);
    if (item) {
      item.read = !item.read;
      window.StorageManager.saveNotifications(notifs);
      this.render();
    }
  },

  deleteNotification(id) {
    const notifs = window.StorageManager.getNotifications().filter(n => n.id !== id);
    window.StorageManager.saveNotifications(notifs);
    this.render();
  },

  markAllAsRead() {
    const notifs = window.StorageManager.getNotifications().map(n => ({ ...n, read: true }));
    window.StorageManager.saveNotifications(notifs);
    window.Utils.showToast('All notifications marked as read', 'info');
    this.render();
  },

  clearAll() {
    window.Utils.confirmDialog({
      title: 'Clear All Notifications',
      message: 'Are you sure you want to dismiss and clear all notifications?',
      confirmText: 'Clear All',
      isDestructive: true,
      onConfirm: () => {
        window.StorageManager.saveNotifications([]);
        window.Utils.showToast('Notification center cleared', 'info');
        this.render();
      }
    });
  }
};

window.NotificationsController = NotificationsController;
