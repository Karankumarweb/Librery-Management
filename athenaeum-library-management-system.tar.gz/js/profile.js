/**
 * Athenaeum Profile Controller
 * User details, simulated password changes, and personal borrowing history
 */

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('profile-page-container')) {
    ProfileController.init();
  }
});

const ProfileController = {
  init() {
    this.renderProfile();
    this.bindEvents();
    this.renderPersonalLoans();
  },

  renderProfile() {
    const user = window.Auth.getCurrentUser();
    if (!user) return;

    const nameInput = document.getElementById('profile-name-input');
    const emailInput = document.getElementById('profile-email-input');
    const roleInput = document.getElementById('profile-role-input');
    const avatarImg = document.getElementById('profile-avatar-display');
    const headerName = document.getElementById('profile-display-name');
    const headerRole = document.getElementById('profile-display-role');

    if (nameInput) nameInput.value = user.name || '';
    if (emailInput) emailInput.value = user.email || '';
    if (roleInput) roleInput.value = user.role || 'Administrator';
    if (avatarImg) avatarImg.src = user.avatar || '/assets/images/avatars/avatar-1.svg';
    if (headerName) headerName.textContent = user.name || 'User';
    if (headerRole) headerRole.textContent = user.role || 'Administrator';
  },

  bindEvents() {
    const profileForm = document.getElementById('profile-details-form');
    const passwordForm = document.getElementById('profile-password-form');

    if (profileForm) {
      profileForm.addEventListener('submit', (e) => this.handleSaveProfile(e));
    }

    if (passwordForm) {
      passwordForm.addEventListener('submit', (e) => this.handleChangePassword(e));
    }
  },

  handleSaveProfile(e) {
    e.preventDefault();
    const nameInput = document.getElementById('profile-name-input');
    const emailInput = document.getElementById('profile-email-input');
    const avatarSelect = document.getElementById('profile-avatar-select');

    const name = nameInput.value.trim();
    const email = emailInput.value.trim();

    if (!name) {
      window.Validation.setFieldError(nameInput, 'Name is required');
      return;
    }
    if (!email || !window.Validation.isValidEmail(email)) {
      window.Validation.setFieldError(emailInput, 'Valid email required');
      return;
    }

    const user = window.Auth.getCurrentUser();
    user.name = name;
    user.email = email;
    if (avatarSelect && avatarSelect.value) {
      user.avatar = avatarSelect.value;
    }

    window.StorageManager.setCurrentUser(user);
    window.Utils.showToast('Profile information updated successfully', 'success');
    this.renderProfile();
    if (window.App) window.App.renderHeaderUserInfo();
  },

  handleChangePassword(e) {
    e.preventDefault();
    const curPass = document.getElementById('current-password-input');
    const newPass = document.getElementById('new-password-input');
    const confPass = document.getElementById('confirm-password-input');

    if (!newPass.value || newPass.value.length < 6) {
      window.Validation.setFieldError(newPass, 'Password must be at least 6 characters');
      return;
    }

    if (newPass.value !== confPass.value) {
      window.Validation.setFieldError(confPass, 'Passwords do not match');
      return;
    }

    document.getElementById('profile-password-form').reset();
    window.Utils.showToast('Simulated password changed successfully', 'success');
  },

  renderPersonalLoans() {
    const tableBody = document.getElementById('profile-loans-body');
    if (!tableBody) return;

    const user = window.Auth.getCurrentUser();
    const loans = window.StorageManager.getLoans();

    // Match either by memberId or borrower name
    const myLoans = loans.filter(l => 
      (user.memberId && l.memberId === user.memberId) ||
      (l.memberName.toLowerCase() === user.name.toLowerCase())
    );

    if (myLoans.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; padding: 2rem; color: var(--text-muted);">
            No personal borrowing activity found for this account.
          </td>
        </tr>
      `;
      return;
    }

    tableBody.innerHTML = myLoans.map(l => {
      let badge = 'badge-info';
      if (l.status === 'Returned') badge = 'badge-success';
      if (l.status === 'Overdue') badge = 'badge-danger';

      return `
        <tr>
          <td class="font-mono tabular-nums"><strong>${l.id}</strong></td>
          <td>${window.Utils.escapeHTML(l.bookTitle)}</td>
          <td class="tabular-nums">${window.Utils.formatDate(l.issueDate)}</td>
          <td class="tabular-nums">${window.Utils.formatDate(l.dueDate)}</td>
          <td><span class="badge ${badge}">${l.status}</span></td>
        </tr>
      `;
    }).join('');
  }
};

window.ProfileController = ProfileController;
